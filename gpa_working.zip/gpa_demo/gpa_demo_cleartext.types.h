#ifndef GENERATED_BAZEL_OUT_K8_OPT_BIN_TRANSPILER_CODELAB_GPA_DEMO_GPA_DEMO_CLEARTEXT_TYPES_H
#define GENERATED_BAZEL_OUT_K8_OPT_BIN_TRANSPILER_CODELAB_GPA_DEMO_GPA_DEMO_CLEARTEXT_TYPES_H

#include <memory>

#include "xls/common/logging/logging.h"
#include "transpiler/data/cleartext_value.h"
#include "bazel-out/k8-opt/bin/transpiler/codelab/gpa_demo/gpa_demo.generic.types.h"
#include "absl/types/span.h"

template <typename T>
using __EncodedBaseRef =
    GenericEncodedRef<T, bool, std::default_delete<bool[]>, void, void, void,
                        ::CleartextCopy, ::CleartextEncode, ::CleartextEncode,
                        ::CleartextDecode>;

template <typename T>
using __EncodedBase =
    GenericEncoded<T, bool, std::default_delete<bool[]>, void, void, void,
                     ::CleartextCopy, ::CleartextEncode, ::CleartextEncode,
                     ::CleartextDecode>;

template <typename T, unsigned... Dimensions>
using __EncodedBaseArrayRef = GenericEncodedArrayRef<T,
    bool, std::default_delete<bool[]>, void, void, void, ::CleartextCopy,
    ::CleartextEncode, ::CleartextEncode, ::CleartextDecode, Dimensions...>;

template <typename T, unsigned... Dimensions>
using __EncodedBaseArray =
    GenericEncodedArray<T, bool, std::default_delete<bool[]>, void, void, void,
                          ::CleartextCopy, ::CleartextEncode, ::CleartextEncode,
                          ::CleartextDecode, Dimensions...>;


#ifndef _CALCULATOR_CLEARTEXT_ENCODED
#define _CALCULATOR_CLEARTEXT_ENCODED
template <>
class EncodedRef<Calculator> : public __EncodedBaseRef<Calculator> {
 public:
  using __EncodedBaseRef<Calculator>::__EncodedBaseRef;

  EncodedRef(const __EncodedBaseRef<Calculator>& rhs)
      : EncodedRef<Calculator>(const_cast<bool*>(rhs.get().data()), rhs.length(), nullptr) {}

  void Encode(const Calculator& value) { SetEncrypted(value, nullptr); }

  Calculator Decode() const { return Decrypt(nullptr); }

  using __EncodedBaseRef<Calculator>::get;

 private:
  using __EncodedBaseRef<Calculator>::BorrowedDecrypt;
  using __EncodedBaseRef<Calculator>::BorrowedSetEncrypted;
  using __EncodedBaseRef<Calculator>::BorrowedSetUnencrypted;
  using __EncodedBaseRef<Calculator>::Decrypt;
  using __EncodedBaseRef<Calculator>::SetEncrypted;
  using __EncodedBaseRef<Calculator>::SetUnencrypted;
};

template <>
class Encoded<Calculator> : public __EncodedBase<Calculator> {
 public:
  Encoded()
      : __EncodedBase<Calculator>(new bool[Encoded<Calculator>::element_bit_width()], 1,
                          std::default_delete<bool[]>(), nullptr) {}
  Encoded(const Calculator& value) : Encoded<Calculator>() { Encode(value); }

  Encoded<Calculator>& operator=(const EncodedRef<Calculator> rhs) {
    ::CleartextCopy(rhs.get(), nullptr, this->get());
    return *this;
  }

  operator const EncodedRef<Calculator>() const& {
    return EncodedRef<Calculator>(const_cast<bool*>(get().data()), this->length(), nullptr);
  }
  operator EncodedRef<Calculator>() & {
    return EncodedRef<Calculator>(const_cast<bool*>(get().data()), this->length(), nullptr);
  }

  void Encode(const Calculator& value) { SetEncrypted(value, nullptr); }

  Calculator Decode() const { return Decrypt(nullptr); }

  using __EncodedBase<Calculator>::get;

 private:
  using __EncodedBase<Calculator>::BorrowedDecrypt;
  using __EncodedBase<Calculator>::BorrowedSetEncrypted;
  using __EncodedBase<Calculator>::BorrowedSetUnencrypted;
  using __EncodedBase<Calculator>::Decrypt;
  using __EncodedBase<Calculator>::SetEncrypted;
  using __EncodedBase<Calculator>::SetUnencrypted;
};

template <>
class EncodedArray<Calculator> : public __EncodedBaseArray<Calculator> {
 public:
  EncodedArray(size_t length)
      : __EncodedBaseArray<Calculator>(new bool[length * Encoded<Calculator>::element_bit_width()],
                             length, std::default_delete<bool[]>(), nullptr) {}

  EncodedArray(std::initializer_list<Calculator> values)
      : EncodedArray<Calculator>(values.size()) {
    Encode(std::data(values), values.size());
  }

  void Encode(const Calculator* value, size_t length) {
    XLS_CHECK(this->length() >= length);
    SetEncrypted(value, length, nullptr);
  }

  void Encode(absl::Span<const Calculator> values) {
    XLS_CHECK(this->length() >= values.size());
    SetEncrypted(values.data(), values.size(), nullptr);
  }

  void Decode(Calculator* value, size_t length) const {
    XLS_CHECK(length >= this->length());
    Decrypt(value, length, nullptr);
  }

  EncodedRef<Calculator> operator[](size_t pos) {
    auto ref = this->__EncodedBaseArray<Calculator>::operator[](pos);
    return EncodedRef<Calculator>(ref);
  }



  absl::FixedArray<Calculator> Decode() const { return Decrypt(nullptr); }

  using __EncodedBaseArray<Calculator>::get;

 private:
  using __EncodedBaseArray<Calculator>::Decrypt;
  using __EncodedBaseArray<Calculator>::SetUnencrypted;
  using __EncodedBaseArray<Calculator>::SetEncrypted;
  using __EncodedBaseArray<Calculator>::BorrowedSetUnencrypted;
  using __EncodedBaseArray<Calculator>::BorrowedSetEncrypted;
  using __EncodedBaseArray<Calculator>::BorrowedDecrypt;
};

template <unsigned D1>
class EncodedArray<Calculator, D1> : public __EncodedBaseArray<Calculator, D1> {
 public:
  EncodedArray()
      : __EncodedBaseArray<Calculator, D1>(
            new bool[__EncodedBaseArray<Calculator, D1>::element_bit_width() * D1], D1,
            std::default_delete<bool[]>(), nullptr) {}

  EncodedArray(std::initializer_list<Calculator> values)
      : EncodedArray<Calculator, D1>() {
    XLS_CHECK_EQ(values.size(), D1);
    Encode(std::data(values));
  }

  EncodedArray(const Calculator values[D1])
      : EncodedArray<Calculator, D1>() {
    Encode(values);
  }

  void Encode(std::add_const_t<typename __EncodedBaseArray<Calculator, D1>::ArrayT> value) {
    SetEncrypted(value, nullptr, 0);
  }

  void Decode(typename __EncodedBaseArray<Calculator, D1>::ArrayT value) const {
    Decrypt(value, nullptr);
  }



  absl::FixedArray<Calculator> Decode() const { return Decrypt(nullptr); }

  EncodedRef<Calculator> operator[](size_t pos) {
    auto ref = this->__EncodedBaseArray<Calculator, D1>::operator[](pos);
    return EncodedRef<Calculator>(ref);
  }

  using __EncodedBaseArray<Calculator, D1>::get;

 private:
  using __EncodedBaseArray<Calculator, D1>::Decrypt;
  using __EncodedBaseArray<Calculator, D1>::SetUnencrypted;
  using __EncodedBaseArray<Calculator, D1>::SetEncrypted;
  using __EncodedBaseArray<Calculator, D1>::BorrowedSetUnencrypted;
  using __EncodedBaseArray<Calculator, D1>::BorrowedSetEncrypted;
  using __EncodedBaseArray<Calculator, D1>::BorrowedDecrypt;
};

template <unsigned D1, unsigned... Dimensions>
class EncodedArray<Calculator, D1, Dimensions...>: public __EncodedBaseArray<Calculator, D1, Dimensions...> {
 public:
  EncodedArray()
      : __EncodedBaseArray<Calculator, D1, Dimensions...>(
            new bool[__EncodedBaseArray<Calculator, D1, Dimensions...>::element_bit_width() *
                     __EncodedBaseArray<Calculator, D1, Dimensions...>::VOLUME],
            __EncodedBaseArray<Calculator, D1, Dimensions...>::VOLUME,
            std::default_delete<bool[]>(), nullptr) {}

  // No initializer_list constructor for multi-dimensional arrays.

  void Encode(std::add_const_t<typename __EncodedBaseArray<Calculator, D1, Dimensions...>::ArrayT> value) {
    SetEncrypted(value, nullptr, 0);
  }

  void Decode(typename __EncodedBaseArray<Calculator, D1, Dimensions...>::ArrayT value) const {
    Decrypt(value, nullptr);
  }

  EncodedArrayRef<Calculator, Dimensions...> operator[](size_t pos) {
    auto ref = this->__EncodedBaseArray<Calculator, D1, Dimensions...>::operator[](pos);
    return EncodedArrayRef<Calculator, Dimensions...>(ref);
  }

  using __EncodedBaseArray<Calculator, D1, Dimensions...>::get;

 private:
  using __EncodedBaseArray<Calculator, D1, Dimensions...>::Decrypt;
  using __EncodedBaseArray<Calculator, D1, Dimensions...>::SetUnencrypted;
  using __EncodedBaseArray<Calculator, D1, Dimensions...>::SetEncrypted;
  using __EncodedBaseArray<Calculator, D1, Dimensions...>::BorrowedSetUnencrypted;
  using __EncodedBaseArray<Calculator, D1, Dimensions...>::BorrowedSetEncrypted;
  using __EncodedBaseArray<Calculator, D1, Dimensions...>::BorrowedDecrypt;
};

template <>
class EncodedArrayRef<Calculator> : public __EncodedBaseArrayRef<Calculator> {
 public:
  using __EncodedBaseArrayRef<Calculator>::__EncodedBaseArrayRef;
  EncodedArrayRef(const __EncodedBaseArrayRef<Calculator>& rhs)
      : EncodedArrayRef(const_cast<bool*>(rhs.get().data()), rhs.length(), rhs.bk()) {}
  EncodedArrayRef(const __EncodedBaseArray<Calculator>& rhs)
      : EncodedArrayRef(const_cast<bool*>(rhs.get().data()), rhs.length(), rhs.bk()) {}

  void Encode(const Calculator* value, size_t length) {
    XLS_CHECK(this->length() >= length);
    SetEncrypted(value, length, nullptr);
  }

  void Decode(Calculator* value, size_t length) const {
    XLS_CHECK(length >= this->length());
    Decrypt(value, length, nullptr);
  }

  absl::FixedArray<Calculator> Decode() const { return Decrypt(nullptr); }

  EncodedRef<Calculator> operator[](size_t pos) {
    auto ref = this->__EncodedBaseArrayRef<Calculator>::operator[](pos);
    return EncodedRef<Calculator>(ref);
  }

 private:
  using __EncodedBaseArrayRef<Calculator>::Decrypt;
  using __EncodedBaseArrayRef<Calculator>::SetUnencrypted;
  using __EncodedBaseArrayRef<Calculator>::SetEncrypted;
  using __EncodedBaseArrayRef<Calculator>::BorrowedSetUnencrypted;
  using __EncodedBaseArrayRef<Calculator>::BorrowedSetEncrypted;
  using __EncodedBaseArrayRef<Calculator>::BorrowedDecrypt;
};

template <unsigned D1>
class EncodedArrayRef<Calculator, D1> : public __EncodedBaseArrayRef<Calculator, D1> {
 public:
  using __EncodedBaseArrayRef<Calculator, D1>::__EncodedBaseArrayRef;

  EncodedArrayRef(const __EncodedBaseArrayRef<Calculator, D1>& rhs)
      : EncodedArrayRef(const_cast<bool*>(rhs.get().data()), rhs.length(), rhs.bk()) {}
  EncodedArrayRef(const __EncodedBaseArray<Calculator, D1>& rhs)
      : EncodedArrayRef(const_cast<bool*>(rhs.get().data()), rhs.length(), rhs.bk()) {}
  EncodedArrayRef(const __EncodedBaseArray<Calculator>& rhs)
      : EncodedArrayRef(const_cast<bool*>(rhs.get().data()), rhs.length(), rhs.bk()) {
    XLS_CHECK_EQ(rhs.length(), D1);
  }

  void Encode(std::add_const_t<typename __EncodedBaseArrayRef<Calculator, D1>::ArrayT> value) {
    SetEncrypted(value, nullptr);
  }

  void Decode(typename __EncodedBaseArrayRef<Calculator, D1>::ArrayT value) const {
    Decrypt(value, nullptr);
  }

  absl::FixedArray<Calculator> Decode() const { return Decrypt(nullptr); }

  EncodedRef<Calculator> operator[](size_t pos) {
    auto ref = this->__EncodedBaseArrayRef<Calculator, D1>::operator[](pos);
    return EncodedRef<Calculator>(ref);
  }

 private:
  using __EncodedBaseArrayRef<Calculator, D1>::Decrypt;
  using __EncodedBaseArrayRef<Calculator, D1>::SetUnencrypted;
  using __EncodedBaseArrayRef<Calculator, D1>::SetEncrypted;
  using __EncodedBaseArrayRef<Calculator, D1>::BorrowedSetUnencrypted;
  using __EncodedBaseArrayRef<Calculator, D1>::BorrowedSetEncrypted;
  using __EncodedBaseArrayRef<Calculator, D1>::BorrowedDecrypt;
};

template <unsigned D1, unsigned... Dimensions>
class EncodedArrayRef<Calculator, D1, Dimensions...> : public __EncodedBaseArrayRef<Calculator, D1, Dimensions...> {
 public:
  using __EncodedBaseArrayRef<Calculator, D1, Dimensions...>::__EncodedBaseArrayRef;
  // Use the VOLUME constant instead of length().  The former gives the total
  // volume of the underlying array (accounting for all dimensions), while the
  // former gives the length of the first level of the array (e.g.,
  // Type[4][3][2] will have VOLUME = 24 and length() == 4.
  EncodedArrayRef(const __EncodedBaseArrayRef<Calculator, D1, Dimensions...>& rhs)
      : EncodedArrayRef(const_cast<bool*>(rhs.get().data()),
                        __EncodedBaseArrayRef<Calculator, D1, Dimensions...>::VOLUME,
                        rhs.bk()) {}
  EncodedArrayRef(const __EncodedBaseArray<Calculator, D1, Dimensions...>& rhs)
      : EncodedArrayRef(const_cast<bool*>(rhs.get().data()),
                        __EncodedBaseArray<Calculator, D1, Dimensions...>::VOLUME,
                        rhs.bk()) {}

  void Encode(
      const typename __EncodedBaseArrayRef<Calculator, D1, Dimensions...>::ArrayT value) {
    SetEncrypted(value, nullptr);
  }

  void Decode(
      typename __EncodedBaseArrayRef<Calculator, D1, Dimensions...>::ArrayT value) const {
    Decrypt(value, nullptr);
  }

  using __EncodedBaseArrayRef<Calculator, D1, Dimensions...>::get;

  EncodedArrayRef<Calculator, Dimensions...> operator[](size_t pos) {
    auto ref = this->__EncodedBaseArrayRef<Calculator, D1, Dimensions...>::operator[](pos);
    return EncodedArrayRef<Calculator, Dimensions...>(ref);
  }

 private:
  using __EncodedBaseArrayRef<Calculator, D1, Dimensions...>::Decrypt;
  using __EncodedBaseArrayRef<Calculator, D1, Dimensions...>::SetUnencrypted;
  using __EncodedBaseArrayRef<Calculator, D1, Dimensions...>::SetEncrypted;
  using __EncodedBaseArrayRef<Calculator, D1, Dimensions...>::BorrowedSetUnencrypted;
  using __EncodedBaseArrayRef<Calculator, D1, Dimensions...>::BorrowedSetEncrypted;
  using __EncodedBaseArrayRef<Calculator, D1, Dimensions...>::BorrowedDecrypt;
};
#endif  // _CALCULATOR_CLEARTEXT_ENCODED

#endif//GENERATED_BAZEL_OUT_K8_OPT_BIN_TRANSPILER_CODELAB_GPA_DEMO_GPA_DEMO_CLEARTEXT_TYPES_H