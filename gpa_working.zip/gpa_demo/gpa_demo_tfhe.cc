#include <unordered_map>

#include "absl/status/status.h"
#include "absl/types/span.h"
#include "transpiler/common_runner.h"
#include "tfhe/tfhe.h"
#include "tfhe/tfhe_io.h"

static StructReverseEncodeOrderSetter ORDER;

absl::Status my_package_UNSAFE(absl::Span<LweSample> result, absl::Span<LweSample> calc, absl::Span<const LweSample> w, absl::Span<const LweSample> x, absl::Span<const LweSample> y, absl::Span<const LweSample> z, const TFheGateBootstrappingCloudKeySet* bk) {
  std::unordered_map<int, LweSample*> temp_nodes;

  temp_nodes[2096] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2096], &w[1], bk);

  temp_nodes[2112] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2112], &x[1], bk);

  temp_nodes[2128] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2128], &y[1], bk);

  temp_nodes[2144] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2144], &z[1], bk);

  temp_nodes[2159] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2159], temp_nodes[2096], temp_nodes[2112], bk);

  temp_nodes[2163] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2163], temp_nodes[2128], temp_nodes[2144], bk);

  temp_nodes[2161] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2161], temp_nodes[2096], temp_nodes[2112], bk);

  temp_nodes[2160] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2160], temp_nodes[2159], bk);

  temp_nodes[2165] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2165], temp_nodes[2128], temp_nodes[2144], bk);

  temp_nodes[2164] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2164], temp_nodes[2163], bk);

  temp_nodes[2162] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2162], temp_nodes[2161], temp_nodes[2160], bk);

  temp_nodes[2095] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2095], &w[0], bk);

  temp_nodes[2166] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2166], temp_nodes[2165], temp_nodes[2164], bk);

  temp_nodes[2127] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2127], &y[0], bk);

  temp_nodes[2097] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2097], &w[2], bk);

  temp_nodes[2113] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2113], &x[2], bk);

  temp_nodes[2129] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2129], &y[2], bk);

  temp_nodes[2145] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2145], &z[2], bk);

  temp_nodes[2111] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2111], &x[0], bk);

  temp_nodes[2190] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2190], temp_nodes[2162], temp_nodes[2095], bk);

  temp_nodes[2143] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2143], &z[0], bk);

  temp_nodes[2194] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2194], temp_nodes[2166], temp_nodes[2127], bk);

  temp_nodes[2173] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2173], temp_nodes[2097], temp_nodes[2113], bk);

  temp_nodes[2168] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2168], temp_nodes[2162], temp_nodes[2095], bk);

  temp_nodes[2178] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2178], temp_nodes[2129], temp_nodes[2145], bk);

  temp_nodes[2171] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2171], temp_nodes[2166], temp_nodes[2127], bk);

  temp_nodes[2183] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2183], temp_nodes[2095], temp_nodes[2111], bk);

  temp_nodes[2191] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2191], temp_nodes[2190], temp_nodes[2111], bk);

  temp_nodes[2184] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2184], temp_nodes[2127], temp_nodes[2143], bk);

  temp_nodes[2195] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2195], temp_nodes[2194], temp_nodes[2143], bk);

  temp_nodes[2098] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2098], &w[3], bk);

  temp_nodes[2114] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2114], &x[3], bk);

  temp_nodes[2175] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2175], temp_nodes[2097], temp_nodes[2113], bk);

  temp_nodes[2174] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2174], temp_nodes[2173], bk);

  temp_nodes[2167] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2167], temp_nodes[2096], temp_nodes[2112], bk);

  temp_nodes[2169] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2169], temp_nodes[2168], temp_nodes[2111], bk);

  temp_nodes[2130] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2130], &y[3], bk);

  temp_nodes[2146] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2146], &z[3], bk);

  temp_nodes[2180] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2180], temp_nodes[2129], temp_nodes[2145], bk);

  temp_nodes[2179] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2179], temp_nodes[2178], bk);

  temp_nodes[2170] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2170], temp_nodes[2128], temp_nodes[2144], bk);

  temp_nodes[2172] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2172], temp_nodes[2171], temp_nodes[2143], bk);

  temp_nodes[2189] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2189], temp_nodes[2162], temp_nodes[2183], bk);

  temp_nodes[2192] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2192], temp_nodes[2191], bk);

  temp_nodes[2193] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2193], temp_nodes[2166], temp_nodes[2184], bk);

  temp_nodes[2196] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2196], temp_nodes[2195], bk);

  temp_nodes[2197] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2197], temp_nodes[2098], temp_nodes[2114], bk);

  temp_nodes[2176] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2176], temp_nodes[2175], temp_nodes[2174], bk);

  temp_nodes[2177] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2177], temp_nodes[2167], temp_nodes[2169], bk);

  temp_nodes[2202] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2202], temp_nodes[2130], temp_nodes[2146], bk);

  temp_nodes[2181] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2181], temp_nodes[2180], temp_nodes[2179], bk);

  temp_nodes[2182] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2182], temp_nodes[2170], temp_nodes[2172], bk);

  temp_nodes[2211] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2211], temp_nodes[2189], temp_nodes[2192], bk);

  temp_nodes[2212] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2212], temp_nodes[2193], temp_nodes[2196], bk);

  temp_nodes[2099] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2099], &w[4], bk);

  temp_nodes[2115] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2115], &x[4], bk);

  temp_nodes[2199] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2199], temp_nodes[2098], temp_nodes[2114], bk);

  temp_nodes[2198] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2198], temp_nodes[2197], bk);

  temp_nodes[2185] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2185], temp_nodes[2097], temp_nodes[2113], bk);

  temp_nodes[2186] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2186], temp_nodes[2176], temp_nodes[2177], bk);

  temp_nodes[2131] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2131], &y[4], bk);

  temp_nodes[2147] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2147], &z[4], bk);

  temp_nodes[2204] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2204], temp_nodes[2130], temp_nodes[2146], bk);

  temp_nodes[2203] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2203], temp_nodes[2202], bk);

  temp_nodes[2187] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2187], temp_nodes[2129], temp_nodes[2145], bk);

  temp_nodes[2188] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2188], temp_nodes[2181], temp_nodes[2182], bk);

  temp_nodes[2219] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2219], temp_nodes[2211], temp_nodes[2212], bk);

  temp_nodes[2237] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2237], temp_nodes[2095], temp_nodes[2111], bk);

  temp_nodes[2220] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2220], temp_nodes[2099], temp_nodes[2115], bk);

  temp_nodes[2200] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2200], temp_nodes[2199], temp_nodes[2198], bk);

  temp_nodes[2201] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2201], temp_nodes[2185], temp_nodes[2186], bk);

  temp_nodes[2225] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2225], temp_nodes[2131], temp_nodes[2147], bk);

  temp_nodes[2205] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2205], temp_nodes[2204], temp_nodes[2203], bk);

  temp_nodes[2206] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2206], temp_nodes[2187], temp_nodes[2188], bk);

  temp_nodes[2207] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2207], temp_nodes[2176], temp_nodes[2177], bk);

  temp_nodes[2208] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2208], temp_nodes[2186], bk);

  temp_nodes[2209] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2209], temp_nodes[2181], temp_nodes[2182], bk);

  temp_nodes[2210] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2210], temp_nodes[2188], bk);

  temp_nodes[2235] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2235], temp_nodes[2211], temp_nodes[2212], bk);

  temp_nodes[2236] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2236], temp_nodes[2219], bk);

  temp_nodes[2239] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2239], temp_nodes[2095], temp_nodes[2111], bk);

  temp_nodes[2238] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2238], temp_nodes[2237], bk);

  temp_nodes[2241] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2241], temp_nodes[2127], temp_nodes[2143], bk);

  temp_nodes[2100] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2100], &w[5], bk);

  temp_nodes[2116] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2116], &x[5], bk);

  temp_nodes[2222] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2222], temp_nodes[2099], temp_nodes[2115], bk);

  temp_nodes[2221] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2221], temp_nodes[2220], bk);

  temp_nodes[2213] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2213], temp_nodes[2098], temp_nodes[2114], bk);

  temp_nodes[2214] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2214], temp_nodes[2200], temp_nodes[2201], bk);

  temp_nodes[2132] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2132], &y[5], bk);

  temp_nodes[2148] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2148], &z[5], bk);

  temp_nodes[2227] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2227], temp_nodes[2131], temp_nodes[2147], bk);

  temp_nodes[2226] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2226], temp_nodes[2225], bk);

  temp_nodes[2215] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2215], temp_nodes[2130], temp_nodes[2146], bk);

  temp_nodes[2216] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2216], temp_nodes[2205], temp_nodes[2206], bk);

  temp_nodes[2217] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2217], temp_nodes[2207], temp_nodes[2208], bk);

  temp_nodes[2218] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2218], temp_nodes[2209], temp_nodes[2210], bk);

  temp_nodes[2253] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2253], temp_nodes[2235], temp_nodes[2236], bk);

  temp_nodes[2240] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2240], temp_nodes[2239], temp_nodes[2238], bk);

  temp_nodes[2243] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2243], temp_nodes[2127], temp_nodes[2143], bk);

  temp_nodes[2242] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2242], temp_nodes[2241], bk);

  temp_nodes[2256] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2256], temp_nodes[2100], temp_nodes[2116], bk);

  temp_nodes[2223] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2223], temp_nodes[2222], temp_nodes[2221], bk);

  temp_nodes[2224] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2224], temp_nodes[2213], temp_nodes[2214], bk);

  temp_nodes[2261] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2261], temp_nodes[2132], temp_nodes[2148], bk);

  temp_nodes[2228] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2228], temp_nodes[2227], temp_nodes[2226], bk);

  temp_nodes[2229] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2229], temp_nodes[2215], temp_nodes[2216], bk);

  temp_nodes[2230] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2230], temp_nodes[2200], temp_nodes[2201], bk);

  temp_nodes[2231] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2231], temp_nodes[2214], bk);

  temp_nodes[2232] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2232], temp_nodes[2205], temp_nodes[2206], bk);

  temp_nodes[2233] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2233], temp_nodes[2216], bk);

  temp_nodes[2234] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2234], temp_nodes[2217], temp_nodes[2218], bk);

  temp_nodes[2254] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2254], temp_nodes[2253], temp_nodes[2240], bk);

  temp_nodes[2244] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2244], temp_nodes[2243], temp_nodes[2242], bk);

  temp_nodes[2101] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2101], &w[6], bk);

  temp_nodes[2117] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2117], &x[6], bk);

  temp_nodes[2258] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2258], temp_nodes[2100], temp_nodes[2116], bk);

  temp_nodes[2257] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2257], temp_nodes[2256], bk);

  temp_nodes[2245] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2245], temp_nodes[2099], temp_nodes[2115], bk);

  temp_nodes[2246] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2246], temp_nodes[2223], temp_nodes[2224], bk);

  temp_nodes[2133] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2133], &y[6], bk);

  temp_nodes[2149] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2149], &z[6], bk);

  temp_nodes[2263] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2263], temp_nodes[2132], temp_nodes[2148], bk);

  temp_nodes[2262] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2262], temp_nodes[2261], bk);

  temp_nodes[2247] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2247], temp_nodes[2131], temp_nodes[2147], bk);

  temp_nodes[2248] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2248], temp_nodes[2228], temp_nodes[2229], bk);

  temp_nodes[2249] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2249], temp_nodes[2230], temp_nodes[2231], bk);

  temp_nodes[2250] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2250], temp_nodes[2232], temp_nodes[2233], bk);

  temp_nodes[2251] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2251], temp_nodes[2217], temp_nodes[2218], bk);

  temp_nodes[2252] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2252], temp_nodes[2234], bk);

  temp_nodes[2255] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2255], temp_nodes[2254], temp_nodes[2244], bk);

  temp_nodes[2282] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2282], temp_nodes[2101], temp_nodes[2117], bk);

  temp_nodes[2259] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2259], temp_nodes[2258], temp_nodes[2257], bk);

  temp_nodes[2260] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2260], temp_nodes[2245], temp_nodes[2246], bk);

  temp_nodes[2287] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2287], temp_nodes[2133], temp_nodes[2149], bk);

  temp_nodes[2264] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2264], temp_nodes[2263], temp_nodes[2262], bk);

  temp_nodes[2265] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2265], temp_nodes[2247], temp_nodes[2248], bk);

  temp_nodes[2266] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2266], temp_nodes[2223], temp_nodes[2224], bk);

  temp_nodes[2267] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2267], temp_nodes[2246], bk);

  temp_nodes[2268] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2268], temp_nodes[2228], temp_nodes[2229], bk);

  temp_nodes[2269] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2269], temp_nodes[2248], bk);

  temp_nodes[2270] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2270], temp_nodes[2249], temp_nodes[2250], bk);

  temp_nodes[2271] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2271], temp_nodes[2251], temp_nodes[2252], bk);

  temp_nodes[2272] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2272], temp_nodes[2219], temp_nodes[2255], bk);

  temp_nodes[2102] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2102], &w[7], bk);

  temp_nodes[2118] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2118], &x[7], bk);

  temp_nodes[2284] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2284], temp_nodes[2101], temp_nodes[2117], bk);

  temp_nodes[2283] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2283], temp_nodes[2282], bk);

  temp_nodes[2273] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2273], temp_nodes[2100], temp_nodes[2116], bk);

  temp_nodes[2274] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2274], temp_nodes[2259], temp_nodes[2260], bk);

  temp_nodes[2134] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2134], &y[7], bk);

  temp_nodes[2150] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2150], &z[7], bk);

  temp_nodes[2289] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2289], temp_nodes[2133], temp_nodes[2149], bk);

  temp_nodes[2288] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2288], temp_nodes[2287], bk);

  temp_nodes[2275] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2275], temp_nodes[2132], temp_nodes[2148], bk);

  temp_nodes[2276] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2276], temp_nodes[2264], temp_nodes[2265], bk);

  temp_nodes[2277] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2277], temp_nodes[2266], temp_nodes[2267], bk);

  temp_nodes[2278] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2278], temp_nodes[2268], temp_nodes[2269], bk);

  temp_nodes[2279] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2279], temp_nodes[2249], temp_nodes[2250], bk);

  temp_nodes[2280] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2280], temp_nodes[2270], bk);

  temp_nodes[2281] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2281], temp_nodes[2271], temp_nodes[2272], bk);

  temp_nodes[2308] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2308], temp_nodes[2102], temp_nodes[2118], bk);

  temp_nodes[2285] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2285], temp_nodes[2284], temp_nodes[2283], bk);

  temp_nodes[2286] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2286], temp_nodes[2273], temp_nodes[2274], bk);

  temp_nodes[2313] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2313], temp_nodes[2134], temp_nodes[2150], bk);

  temp_nodes[2290] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2290], temp_nodes[2289], temp_nodes[2288], bk);

  temp_nodes[2291] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2291], temp_nodes[2275], temp_nodes[2276], bk);

  temp_nodes[2292] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2292], temp_nodes[2259], temp_nodes[2260], bk);

  temp_nodes[2293] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2293], temp_nodes[2274], bk);

  temp_nodes[2294] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2294], temp_nodes[2264], temp_nodes[2265], bk);

  temp_nodes[2295] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2295], temp_nodes[2276], bk);

  temp_nodes[2296] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2296], temp_nodes[2277], temp_nodes[2278], bk);

  temp_nodes[2297] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2297], temp_nodes[2279], temp_nodes[2280], bk);

  temp_nodes[2298] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2298], temp_nodes[2234], temp_nodes[2281], bk);

  temp_nodes[2103] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2103], &w[8], bk);

  temp_nodes[2119] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2119], &x[8], bk);

  temp_nodes[2310] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2310], temp_nodes[2102], temp_nodes[2118], bk);

  temp_nodes[2309] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2309], temp_nodes[2308], bk);

  temp_nodes[2299] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2299], temp_nodes[2101], temp_nodes[2117], bk);

  temp_nodes[2300] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2300], temp_nodes[2285], temp_nodes[2286], bk);

  temp_nodes[2135] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2135], &y[8], bk);

  temp_nodes[2151] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2151], &z[8], bk);

  temp_nodes[2315] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2315], temp_nodes[2134], temp_nodes[2150], bk);

  temp_nodes[2314] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2314], temp_nodes[2313], bk);

  temp_nodes[2301] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2301], temp_nodes[2133], temp_nodes[2149], bk);

  temp_nodes[2302] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2302], temp_nodes[2290], temp_nodes[2291], bk);

  temp_nodes[2303] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2303], temp_nodes[2292], temp_nodes[2293], bk);

  temp_nodes[2304] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2304], temp_nodes[2294], temp_nodes[2295], bk);

  temp_nodes[2305] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2305], temp_nodes[2277], temp_nodes[2278], bk);

  temp_nodes[2306] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2306], temp_nodes[2296], bk);

  temp_nodes[2307] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2307], temp_nodes[2297], temp_nodes[2298], bk);

  temp_nodes[2334] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2334], temp_nodes[2103], temp_nodes[2119], bk);

  temp_nodes[2311] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2311], temp_nodes[2310], temp_nodes[2309], bk);

  temp_nodes[2312] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2312], temp_nodes[2299], temp_nodes[2300], bk);

  temp_nodes[2339] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2339], temp_nodes[2135], temp_nodes[2151], bk);

  temp_nodes[2316] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2316], temp_nodes[2315], temp_nodes[2314], bk);

  temp_nodes[2317] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2317], temp_nodes[2301], temp_nodes[2302], bk);

  temp_nodes[2318] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2318], temp_nodes[2285], temp_nodes[2286], bk);

  temp_nodes[2319] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2319], temp_nodes[2300], bk);

  temp_nodes[2320] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2320], temp_nodes[2290], temp_nodes[2291], bk);

  temp_nodes[2321] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2321], temp_nodes[2302], bk);

  temp_nodes[2322] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2322], temp_nodes[2303], temp_nodes[2304], bk);

  temp_nodes[2323] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2323], temp_nodes[2305], temp_nodes[2306], bk);

  temp_nodes[2324] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2324], temp_nodes[2270], temp_nodes[2307], bk);

  temp_nodes[2104] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2104], &w[9], bk);

  temp_nodes[2120] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2120], &x[9], bk);

  temp_nodes[2336] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2336], temp_nodes[2103], temp_nodes[2119], bk);

  temp_nodes[2335] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2335], temp_nodes[2334], bk);

  temp_nodes[2325] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2325], temp_nodes[2102], temp_nodes[2118], bk);

  temp_nodes[2326] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2326], temp_nodes[2311], temp_nodes[2312], bk);

  temp_nodes[2136] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2136], &y[9], bk);

  temp_nodes[2152] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2152], &z[9], bk);

  temp_nodes[2341] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2341], temp_nodes[2135], temp_nodes[2151], bk);

  temp_nodes[2340] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2340], temp_nodes[2339], bk);

  temp_nodes[2327] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2327], temp_nodes[2134], temp_nodes[2150], bk);

  temp_nodes[2328] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2328], temp_nodes[2316], temp_nodes[2317], bk);

  temp_nodes[2329] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2329], temp_nodes[2318], temp_nodes[2319], bk);

  temp_nodes[2330] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2330], temp_nodes[2320], temp_nodes[2321], bk);

  temp_nodes[2331] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2331], temp_nodes[2303], temp_nodes[2304], bk);

  temp_nodes[2332] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2332], temp_nodes[2322], bk);

  temp_nodes[2333] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2333], temp_nodes[2323], temp_nodes[2324], bk);

  temp_nodes[2360] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2360], temp_nodes[2104], temp_nodes[2120], bk);

  temp_nodes[2337] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2337], temp_nodes[2336], temp_nodes[2335], bk);

  temp_nodes[2338] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2338], temp_nodes[2325], temp_nodes[2326], bk);

  temp_nodes[2365] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2365], temp_nodes[2136], temp_nodes[2152], bk);

  temp_nodes[2342] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2342], temp_nodes[2341], temp_nodes[2340], bk);

  temp_nodes[2343] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2343], temp_nodes[2327], temp_nodes[2328], bk);

  temp_nodes[2344] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2344], temp_nodes[2311], temp_nodes[2312], bk);

  temp_nodes[2345] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2345], temp_nodes[2326], bk);

  temp_nodes[2346] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2346], temp_nodes[2316], temp_nodes[2317], bk);

  temp_nodes[2347] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2347], temp_nodes[2328], bk);

  temp_nodes[2348] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2348], temp_nodes[2329], temp_nodes[2330], bk);

  temp_nodes[2349] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2349], temp_nodes[2331], temp_nodes[2332], bk);

  temp_nodes[2350] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2350], temp_nodes[2296], temp_nodes[2333], bk);

  temp_nodes[2105] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2105], &w[10], bk);

  temp_nodes[2121] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2121], &x[10], bk);

  temp_nodes[2362] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2362], temp_nodes[2104], temp_nodes[2120], bk);

  temp_nodes[2361] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2361], temp_nodes[2360], bk);

  temp_nodes[2351] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2351], temp_nodes[2103], temp_nodes[2119], bk);

  temp_nodes[2352] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2352], temp_nodes[2337], temp_nodes[2338], bk);

  temp_nodes[2137] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2137], &y[10], bk);

  temp_nodes[2153] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2153], &z[10], bk);

  temp_nodes[2367] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2367], temp_nodes[2136], temp_nodes[2152], bk);

  temp_nodes[2366] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2366], temp_nodes[2365], bk);

  temp_nodes[2353] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2353], temp_nodes[2135], temp_nodes[2151], bk);

  temp_nodes[2354] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2354], temp_nodes[2342], temp_nodes[2343], bk);

  temp_nodes[2355] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2355], temp_nodes[2344], temp_nodes[2345], bk);

  temp_nodes[2356] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2356], temp_nodes[2346], temp_nodes[2347], bk);

  temp_nodes[2357] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2357], temp_nodes[2329], temp_nodes[2330], bk);

  temp_nodes[2358] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2358], temp_nodes[2348], bk);

  temp_nodes[2359] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2359], temp_nodes[2349], temp_nodes[2350], bk);

  temp_nodes[2386] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2386], temp_nodes[2105], temp_nodes[2121], bk);

  temp_nodes[2363] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2363], temp_nodes[2362], temp_nodes[2361], bk);

  temp_nodes[2364] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2364], temp_nodes[2351], temp_nodes[2352], bk);

  temp_nodes[2391] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2391], temp_nodes[2137], temp_nodes[2153], bk);

  temp_nodes[2368] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2368], temp_nodes[2367], temp_nodes[2366], bk);

  temp_nodes[2369] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2369], temp_nodes[2353], temp_nodes[2354], bk);

  temp_nodes[2370] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2370], temp_nodes[2337], temp_nodes[2338], bk);

  temp_nodes[2371] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2371], temp_nodes[2352], bk);

  temp_nodes[2372] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2372], temp_nodes[2342], temp_nodes[2343], bk);

  temp_nodes[2373] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2373], temp_nodes[2354], bk);

  temp_nodes[2374] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2374], temp_nodes[2355], temp_nodes[2356], bk);

  temp_nodes[2375] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2375], temp_nodes[2357], temp_nodes[2358], bk);

  temp_nodes[2376] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2376], temp_nodes[2322], temp_nodes[2359], bk);

  temp_nodes[2106] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2106], &w[11], bk);

  temp_nodes[2122] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2122], &x[11], bk);

  temp_nodes[2388] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2388], temp_nodes[2105], temp_nodes[2121], bk);

  temp_nodes[2387] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2387], temp_nodes[2386], bk);

  temp_nodes[2377] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2377], temp_nodes[2104], temp_nodes[2120], bk);

  temp_nodes[2378] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2378], temp_nodes[2363], temp_nodes[2364], bk);

  temp_nodes[2138] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2138], &y[11], bk);

  temp_nodes[2154] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2154], &z[11], bk);

  temp_nodes[2393] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2393], temp_nodes[2137], temp_nodes[2153], bk);

  temp_nodes[2392] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2392], temp_nodes[2391], bk);

  temp_nodes[2379] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2379], temp_nodes[2136], temp_nodes[2152], bk);

  temp_nodes[2380] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2380], temp_nodes[2368], temp_nodes[2369], bk);

  temp_nodes[2381] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2381], temp_nodes[2370], temp_nodes[2371], bk);

  temp_nodes[2382] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2382], temp_nodes[2372], temp_nodes[2373], bk);

  temp_nodes[2383] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2383], temp_nodes[2355], temp_nodes[2356], bk);

  temp_nodes[2384] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2384], temp_nodes[2374], bk);

  temp_nodes[2385] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2385], temp_nodes[2375], temp_nodes[2376], bk);

  temp_nodes[2412] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2412], temp_nodes[2106], temp_nodes[2122], bk);

  temp_nodes[2389] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2389], temp_nodes[2388], temp_nodes[2387], bk);

  temp_nodes[2390] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2390], temp_nodes[2377], temp_nodes[2378], bk);

  temp_nodes[2417] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2417], temp_nodes[2138], temp_nodes[2154], bk);

  temp_nodes[2394] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2394], temp_nodes[2393], temp_nodes[2392], bk);

  temp_nodes[2395] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2395], temp_nodes[2379], temp_nodes[2380], bk);

  temp_nodes[2396] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2396], temp_nodes[2363], temp_nodes[2364], bk);

  temp_nodes[2397] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2397], temp_nodes[2378], bk);

  temp_nodes[2398] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2398], temp_nodes[2368], temp_nodes[2369], bk);

  temp_nodes[2399] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2399], temp_nodes[2380], bk);

  temp_nodes[2400] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2400], temp_nodes[2381], temp_nodes[2382], bk);

  temp_nodes[2401] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2401], temp_nodes[2383], temp_nodes[2384], bk);

  temp_nodes[2402] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2402], temp_nodes[2348], temp_nodes[2385], bk);

  temp_nodes[2107] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2107], &w[12], bk);

  temp_nodes[2123] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2123], &x[12], bk);

  temp_nodes[2414] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2414], temp_nodes[2106], temp_nodes[2122], bk);

  temp_nodes[2413] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2413], temp_nodes[2412], bk);

  temp_nodes[2403] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2403], temp_nodes[2105], temp_nodes[2121], bk);

  temp_nodes[2404] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2404], temp_nodes[2389], temp_nodes[2390], bk);

  temp_nodes[2139] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2139], &y[12], bk);

  temp_nodes[2155] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2155], &z[12], bk);

  temp_nodes[2419] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2419], temp_nodes[2138], temp_nodes[2154], bk);

  temp_nodes[2418] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2418], temp_nodes[2417], bk);

  temp_nodes[2405] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2405], temp_nodes[2137], temp_nodes[2153], bk);

  temp_nodes[2406] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2406], temp_nodes[2394], temp_nodes[2395], bk);

  temp_nodes[2407] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2407], temp_nodes[2396], temp_nodes[2397], bk);

  temp_nodes[2408] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2408], temp_nodes[2398], temp_nodes[2399], bk);

  temp_nodes[2409] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2409], temp_nodes[2381], temp_nodes[2382], bk);

  temp_nodes[2410] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2410], temp_nodes[2400], bk);

  temp_nodes[2411] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2411], temp_nodes[2401], temp_nodes[2402], bk);

  temp_nodes[2438] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2438], temp_nodes[2107], temp_nodes[2123], bk);

  temp_nodes[2415] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2415], temp_nodes[2414], temp_nodes[2413], bk);

  temp_nodes[2416] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2416], temp_nodes[2403], temp_nodes[2404], bk);

  temp_nodes[2443] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2443], temp_nodes[2139], temp_nodes[2155], bk);

  temp_nodes[2420] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2420], temp_nodes[2419], temp_nodes[2418], bk);

  temp_nodes[2421] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2421], temp_nodes[2405], temp_nodes[2406], bk);

  temp_nodes[2422] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2422], temp_nodes[2389], temp_nodes[2390], bk);

  temp_nodes[2423] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2423], temp_nodes[2404], bk);

  temp_nodes[2424] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2424], temp_nodes[2394], temp_nodes[2395], bk);

  temp_nodes[2425] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2425], temp_nodes[2406], bk);

  temp_nodes[2426] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2426], temp_nodes[2407], temp_nodes[2408], bk);

  temp_nodes[2427] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2427], temp_nodes[2409], temp_nodes[2410], bk);

  temp_nodes[2428] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2428], temp_nodes[2374], temp_nodes[2411], bk);

  temp_nodes[2108] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2108], &w[13], bk);

  temp_nodes[2124] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2124], &x[13], bk);

  temp_nodes[2440] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2440], temp_nodes[2107], temp_nodes[2123], bk);

  temp_nodes[2439] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2439], temp_nodes[2438], bk);

  temp_nodes[2429] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2429], temp_nodes[2106], temp_nodes[2122], bk);

  temp_nodes[2430] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2430], temp_nodes[2415], temp_nodes[2416], bk);

  temp_nodes[2140] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2140], &y[13], bk);

  temp_nodes[2156] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2156], &z[13], bk);

  temp_nodes[2445] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2445], temp_nodes[2139], temp_nodes[2155], bk);

  temp_nodes[2444] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2444], temp_nodes[2443], bk);

  temp_nodes[2431] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2431], temp_nodes[2138], temp_nodes[2154], bk);

  temp_nodes[2432] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2432], temp_nodes[2420], temp_nodes[2421], bk);

  temp_nodes[2433] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2433], temp_nodes[2422], temp_nodes[2423], bk);

  temp_nodes[2434] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2434], temp_nodes[2424], temp_nodes[2425], bk);

  temp_nodes[2435] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2435], temp_nodes[2407], temp_nodes[2408], bk);

  temp_nodes[2436] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2436], temp_nodes[2426], bk);

  temp_nodes[2437] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2437], temp_nodes[2427], temp_nodes[2428], bk);

  temp_nodes[2464] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2464], temp_nodes[2108], temp_nodes[2124], bk);

  temp_nodes[2441] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2441], temp_nodes[2440], temp_nodes[2439], bk);

  temp_nodes[2442] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2442], temp_nodes[2429], temp_nodes[2430], bk);

  temp_nodes[2469] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2469], temp_nodes[2140], temp_nodes[2156], bk);

  temp_nodes[2446] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2446], temp_nodes[2445], temp_nodes[2444], bk);

  temp_nodes[2447] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2447], temp_nodes[2431], temp_nodes[2432], bk);

  temp_nodes[2448] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2448], temp_nodes[2415], temp_nodes[2416], bk);

  temp_nodes[2449] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2449], temp_nodes[2430], bk);

  temp_nodes[2450] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2450], temp_nodes[2420], temp_nodes[2421], bk);

  temp_nodes[2451] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2451], temp_nodes[2432], bk);

  temp_nodes[2452] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2452], temp_nodes[2433], temp_nodes[2434], bk);

  temp_nodes[2453] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2453], temp_nodes[2435], temp_nodes[2436], bk);

  temp_nodes[2454] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2454], temp_nodes[2400], temp_nodes[2437], bk);

  temp_nodes[2109] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2109], &w[14], bk);

  temp_nodes[2125] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2125], &x[14], bk);

  temp_nodes[2466] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2466], temp_nodes[2108], temp_nodes[2124], bk);

  temp_nodes[2465] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2465], temp_nodes[2464], bk);

  temp_nodes[2455] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2455], temp_nodes[2107], temp_nodes[2123], bk);

  temp_nodes[2456] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2456], temp_nodes[2441], temp_nodes[2442], bk);

  temp_nodes[2141] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2141], &y[14], bk);

  temp_nodes[2157] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2157], &z[14], bk);

  temp_nodes[2471] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2471], temp_nodes[2140], temp_nodes[2156], bk);

  temp_nodes[2470] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2470], temp_nodes[2469], bk);

  temp_nodes[2457] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2457], temp_nodes[2139], temp_nodes[2155], bk);

  temp_nodes[2458] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2458], temp_nodes[2446], temp_nodes[2447], bk);

  temp_nodes[2459] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2459], temp_nodes[2448], temp_nodes[2449], bk);

  temp_nodes[2460] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2460], temp_nodes[2450], temp_nodes[2451], bk);

  temp_nodes[2461] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2461], temp_nodes[2433], temp_nodes[2434], bk);

  temp_nodes[2462] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2462], temp_nodes[2452], bk);

  temp_nodes[2463] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2463], temp_nodes[2453], temp_nodes[2454], bk);

  temp_nodes[2490] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2490], temp_nodes[2109], temp_nodes[2125], bk);

  temp_nodes[2467] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2467], temp_nodes[2466], temp_nodes[2465], bk);

  temp_nodes[2468] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2468], temp_nodes[2455], temp_nodes[2456], bk);

  temp_nodes[2495] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2495], temp_nodes[2141], temp_nodes[2157], bk);

  temp_nodes[2472] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2472], temp_nodes[2471], temp_nodes[2470], bk);

  temp_nodes[2473] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2473], temp_nodes[2457], temp_nodes[2458], bk);

  temp_nodes[2474] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2474], temp_nodes[2441], temp_nodes[2442], bk);

  temp_nodes[2475] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2475], temp_nodes[2456], bk);

  temp_nodes[2476] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2476], temp_nodes[2446], temp_nodes[2447], bk);

  temp_nodes[2477] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2477], temp_nodes[2458], bk);

  temp_nodes[2478] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2478], temp_nodes[2459], temp_nodes[2460], bk);

  temp_nodes[2479] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2479], temp_nodes[2461], temp_nodes[2462], bk);

  temp_nodes[2480] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2480], temp_nodes[2426], temp_nodes[2463], bk);

  temp_nodes[2110] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2110], &w[15], bk);

  temp_nodes[2126] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2126], &x[15], bk);

  temp_nodes[2492] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2492], temp_nodes[2109], temp_nodes[2125], bk);

  temp_nodes[2491] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2491], temp_nodes[2490], bk);

  temp_nodes[2481] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2481], temp_nodes[2108], temp_nodes[2124], bk);

  temp_nodes[2482] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2482], temp_nodes[2467], temp_nodes[2468], bk);

  temp_nodes[2142] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2142], &y[15], bk);

  temp_nodes[2158] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCOPY(temp_nodes[2158], &z[15], bk);

  temp_nodes[2497] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2497], temp_nodes[2141], temp_nodes[2157], bk);

  temp_nodes[2496] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2496], temp_nodes[2495], bk);

  temp_nodes[2483] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2483], temp_nodes[2140], temp_nodes[2156], bk);

  temp_nodes[2484] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2484], temp_nodes[2472], temp_nodes[2473], bk);

  temp_nodes[2485] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2485], temp_nodes[2474], temp_nodes[2475], bk);

  temp_nodes[2486] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2486], temp_nodes[2476], temp_nodes[2477], bk);

  temp_nodes[2487] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2487], temp_nodes[2459], temp_nodes[2460], bk);

  temp_nodes[2488] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2488], temp_nodes[2478], bk);

  temp_nodes[2489] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2489], temp_nodes[2479], temp_nodes[2480], bk);

  temp_nodes[2516] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2516], temp_nodes[2110], temp_nodes[2126], bk);

  temp_nodes[2493] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2493], temp_nodes[2492], temp_nodes[2491], bk);

  temp_nodes[2494] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2494], temp_nodes[2481], temp_nodes[2482], bk);

  temp_nodes[2521] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2521], temp_nodes[2142], temp_nodes[2158], bk);

  temp_nodes[2498] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2498], temp_nodes[2497], temp_nodes[2496], bk);

  temp_nodes[2499] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2499], temp_nodes[2483], temp_nodes[2484], bk);

  temp_nodes[2500] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2500], temp_nodes[2467], temp_nodes[2468], bk);

  temp_nodes[2501] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2501], temp_nodes[2482], bk);

  temp_nodes[2502] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2502], temp_nodes[2472], temp_nodes[2473], bk);

  temp_nodes[2503] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2503], temp_nodes[2484], bk);

  temp_nodes[2504] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2504], temp_nodes[2485], temp_nodes[2486], bk);

  temp_nodes[2505] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2505], temp_nodes[2487], temp_nodes[2488], bk);

  temp_nodes[2506] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2506], temp_nodes[2452], temp_nodes[2489], bk);

  temp_nodes[2518] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2518], temp_nodes[2110], temp_nodes[2126], bk);

  temp_nodes[2517] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2517], temp_nodes[2516], bk);

  temp_nodes[2507] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2507], temp_nodes[2109], temp_nodes[2125], bk);

  temp_nodes[2508] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2508], temp_nodes[2493], temp_nodes[2494], bk);

  temp_nodes[2523] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2523], temp_nodes[2142], temp_nodes[2158], bk);

  temp_nodes[2522] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2522], temp_nodes[2521], bk);

  temp_nodes[2509] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2509], temp_nodes[2141], temp_nodes[2157], bk);

  temp_nodes[2510] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2510], temp_nodes[2498], temp_nodes[2499], bk);

  temp_nodes[2511] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2511], temp_nodes[2500], temp_nodes[2501], bk);

  temp_nodes[2512] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2512], temp_nodes[2502], temp_nodes[2503], bk);

  temp_nodes[2513] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2513], temp_nodes[2485], temp_nodes[2486], bk);

  temp_nodes[2514] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2514], temp_nodes[2504], bk);

  temp_nodes[2515] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2515], temp_nodes[2505], temp_nodes[2506], bk);

  temp_nodes[2519] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2519], temp_nodes[2518], temp_nodes[2517], bk);

  temp_nodes[2520] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2520], temp_nodes[2507], temp_nodes[2508], bk);

  temp_nodes[2524] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2524], temp_nodes[2523], temp_nodes[2522], bk);

  temp_nodes[2525] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2525], temp_nodes[2509], temp_nodes[2510], bk);

  temp_nodes[2526] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2526], temp_nodes[2493], temp_nodes[2494], bk);

  temp_nodes[2527] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2527], temp_nodes[2508], bk);

  temp_nodes[2528] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2528], temp_nodes[2498], temp_nodes[2499], bk);

  temp_nodes[2529] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2529], temp_nodes[2510], bk);

  temp_nodes[2530] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2530], temp_nodes[2511], temp_nodes[2512], bk);

  temp_nodes[2531] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2531], temp_nodes[2513], temp_nodes[2514], bk);

  temp_nodes[2532] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2532], temp_nodes[2478], temp_nodes[2515], bk);

  temp_nodes[2533] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2533], temp_nodes[2519], temp_nodes[2520], bk);

  temp_nodes[2534] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2534], temp_nodes[2524], temp_nodes[2525], bk);

  temp_nodes[2535] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2535], temp_nodes[2526], temp_nodes[2527], bk);

  temp_nodes[2536] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2536], temp_nodes[2528], temp_nodes[2529], bk);

  temp_nodes[2537] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2537], temp_nodes[2511], temp_nodes[2512], bk);

  temp_nodes[2538] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2538], temp_nodes[2530], bk);

  temp_nodes[2539] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2539], temp_nodes[2531], temp_nodes[2532], bk);

  temp_nodes[2547] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2547], temp_nodes[2110], temp_nodes[2126], bk);

  temp_nodes[2548] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2548], temp_nodes[2142], temp_nodes[2158], bk);

  temp_nodes[2540] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2540], temp_nodes[2519], temp_nodes[2520], bk);

  temp_nodes[2541] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2541], temp_nodes[2533], bk);

  temp_nodes[2542] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2542], temp_nodes[2524], temp_nodes[2525], bk);

  temp_nodes[2543] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2543], temp_nodes[2534], bk);

  temp_nodes[2544] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2544], temp_nodes[2535], temp_nodes[2536], bk);

  temp_nodes[2545] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2545], temp_nodes[2537], temp_nodes[2538], bk);

  temp_nodes[2546] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2546], temp_nodes[2504], temp_nodes[2539], bk);

  temp_nodes[2554] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2554], temp_nodes[2519], temp_nodes[2547], bk);

  temp_nodes[2556] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2556], temp_nodes[2524], temp_nodes[2548], bk);

  temp_nodes[2549] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2549], temp_nodes[2540], temp_nodes[2541], bk);

  temp_nodes[2550] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2550], temp_nodes[2542], temp_nodes[2543], bk);

  temp_nodes[2551] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2551], temp_nodes[2535], temp_nodes[2536], bk);

  temp_nodes[2552] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2552], temp_nodes[2544], bk);

  temp_nodes[2553] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2553], temp_nodes[2545], temp_nodes[2546], bk);

  temp_nodes[2555] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2555], temp_nodes[2554], temp_nodes[2533], bk);

  temp_nodes[2557] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2557], temp_nodes[2556], temp_nodes[2534], bk);

  temp_nodes[2558] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2558], temp_nodes[2549], temp_nodes[2550], bk);

  temp_nodes[2559] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2559], temp_nodes[2551], temp_nodes[2552], bk);

  temp_nodes[2560] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2560], temp_nodes[2530], temp_nodes[2553], bk);

  temp_nodes[2561] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2561], temp_nodes[2555], temp_nodes[2541], bk);

  temp_nodes[2562] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2562], temp_nodes[2557], temp_nodes[2543], bk);

  temp_nodes[2563] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2563], temp_nodes[2549], temp_nodes[2550], bk);

  temp_nodes[2564] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2564], temp_nodes[2558], bk);

  temp_nodes[2565] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2565], temp_nodes[2559], temp_nodes[2560], bk);

  temp_nodes[2566] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2566], temp_nodes[2561], temp_nodes[2562], bk);

  temp_nodes[2567] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2567], temp_nodes[2563], temp_nodes[2564], bk);

  temp_nodes[2568] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2568], temp_nodes[2544], temp_nodes[2565], bk);

  temp_nodes[2569] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2569], temp_nodes[2561], temp_nodes[2562], bk);

  temp_nodes[2570] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2570], temp_nodes[2566], bk);

  temp_nodes[2571] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2571], temp_nodes[2567], temp_nodes[2568], bk);

  temp_nodes[2572] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2572], temp_nodes[2569], temp_nodes[2570], bk);

  temp_nodes[2573] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2573], temp_nodes[2558], temp_nodes[2571], bk);

  temp_nodes[2575] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2575], temp_nodes[2572], temp_nodes[2566], bk);

  temp_nodes[2574] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2574], temp_nodes[2572], temp_nodes[2573], bk);

  temp_nodes[2576] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2576], temp_nodes[2575], temp_nodes[2574], bk);

  temp_nodes[2577] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2577], temp_nodes[2574], bk);

  temp_nodes[2578] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2578], temp_nodes[2572], temp_nodes[2573], bk);

  temp_nodes[2579] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2579], temp_nodes[2567], temp_nodes[2568], bk);

  temp_nodes[2580] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2580], temp_nodes[2571], bk);

  temp_nodes[2581] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2581], temp_nodes[2559], temp_nodes[2560], bk);

  temp_nodes[2582] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2582], temp_nodes[2565], bk);

  temp_nodes[2583] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2583], temp_nodes[2545], temp_nodes[2546], bk);

  temp_nodes[2584] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2584], temp_nodes[2553], bk);

  temp_nodes[2585] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2585], temp_nodes[2531], temp_nodes[2532], bk);

  temp_nodes[2586] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2586], temp_nodes[2539], bk);

  temp_nodes[2587] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2587], temp_nodes[2505], temp_nodes[2506], bk);

  temp_nodes[2588] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2588], temp_nodes[2515], bk);

  temp_nodes[2589] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2589], temp_nodes[2479], temp_nodes[2480], bk);

  temp_nodes[2590] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2590], temp_nodes[2489], bk);

  temp_nodes[2591] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2591], temp_nodes[2453], temp_nodes[2454], bk);

  temp_nodes[2592] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2592], temp_nodes[2463], bk);

  temp_nodes[2593] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2593], temp_nodes[2427], temp_nodes[2428], bk);

  temp_nodes[2594] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2594], temp_nodes[2437], bk);

  temp_nodes[2595] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2595], temp_nodes[2401], temp_nodes[2402], bk);

  temp_nodes[2596] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2596], temp_nodes[2411], bk);

  temp_nodes[2597] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2597], temp_nodes[2375], temp_nodes[2376], bk);

  temp_nodes[2598] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2598], temp_nodes[2385], bk);

  temp_nodes[2599] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2599], temp_nodes[2349], temp_nodes[2350], bk);

  temp_nodes[2600] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2600], temp_nodes[2359], bk);

  temp_nodes[2601] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2601], temp_nodes[2323], temp_nodes[2324], bk);

  temp_nodes[2602] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2602], temp_nodes[2333], bk);

  temp_nodes[2603] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2603], temp_nodes[2297], temp_nodes[2298], bk);

  temp_nodes[2604] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2604], temp_nodes[2307], bk);

  temp_nodes[2605] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsOR(temp_nodes[2605], temp_nodes[2271], temp_nodes[2272], bk);

  temp_nodes[2606] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsNOT(temp_nodes[2606], temp_nodes[2281], bk);

  temp_nodes[2607] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2607], temp_nodes[2576], temp_nodes[2577], bk);

  temp_nodes[2608] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2608], temp_nodes[2578], temp_nodes[2577], bk);

  temp_nodes[2609] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2609], temp_nodes[2579], temp_nodes[2580], bk);

  temp_nodes[2610] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2610], temp_nodes[2581], temp_nodes[2582], bk);

  temp_nodes[2611] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2611], temp_nodes[2583], temp_nodes[2584], bk);

  temp_nodes[2612] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2612], temp_nodes[2585], temp_nodes[2586], bk);

  temp_nodes[2613] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2613], temp_nodes[2587], temp_nodes[2588], bk);

  temp_nodes[2614] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2614], temp_nodes[2589], temp_nodes[2590], bk);

  temp_nodes[2615] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2615], temp_nodes[2591], temp_nodes[2592], bk);

  temp_nodes[2616] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2616], temp_nodes[2593], temp_nodes[2594], bk);

  temp_nodes[2617] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2617], temp_nodes[2595], temp_nodes[2596], bk);

  temp_nodes[2618] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2618], temp_nodes[2597], temp_nodes[2598], bk);

  temp_nodes[2619] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2619], temp_nodes[2599], temp_nodes[2600], bk);

  temp_nodes[2620] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2620], temp_nodes[2601], temp_nodes[2602], bk);

  temp_nodes[2621] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2621], temp_nodes[2603], temp_nodes[2604], bk);

  temp_nodes[2622] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsAND(temp_nodes[2622], temp_nodes[2605], temp_nodes[2606], bk);

  temp_nodes[2088] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCONSTANT(temp_nodes[2088], 1, bk);

  temp_nodes[2089] = new_gate_bootstrapping_ciphertext(bk->params);
  bootsCONSTANT(temp_nodes[2089], 0, bk);

  bootsCOPY(&result[15], temp_nodes[2607], bk);
  bootsCOPY(&result[14], temp_nodes[2608], bk);
  bootsCOPY(&result[13], temp_nodes[2609], bk);
  bootsCOPY(&result[12], temp_nodes[2610], bk);
  bootsCOPY(&result[11], temp_nodes[2611], bk);
  bootsCOPY(&result[10], temp_nodes[2612], bk);
  bootsCOPY(&result[9], temp_nodes[2613], bk);
  bootsCOPY(&result[8], temp_nodes[2614], bk);
  bootsCOPY(&result[7], temp_nodes[2615], bk);
  bootsCOPY(&result[6], temp_nodes[2616], bk);
  bootsCOPY(&result[5], temp_nodes[2617], bk);
  bootsCOPY(&result[4], temp_nodes[2618], bk);
  bootsCOPY(&result[3], temp_nodes[2619], bk);
  bootsCOPY(&result[2], temp_nodes[2620], bk);
  bootsCOPY(&result[1], temp_nodes[2621], bk);
  bootsCOPY(&result[0], temp_nodes[2622], bk);
  for (auto pair : temp_nodes) {
    delete_gate_bootstrapping_ciphertext(pair.second);
  }
  return absl::OkStatus();
}
