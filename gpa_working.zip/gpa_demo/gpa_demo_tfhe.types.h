#ifndef GENERATED_BAZEL_OUT_K8_OPT_BIN_TRANSPILER_CODELAB_GPA_DEMO_GPA_DEMO_TFHE_TYPES_H
#define GENERATED_BAZEL_OUT_K8_OPT_BIN_TRANSPILER_CODELAB_GPA_DEMO_GPA_DEMO_TFHE_TYPES_H

#include <memory>

#include "transpiler/data/tfhe_value.h"
#include "bazel-out/k8-opt/bin/transpiler/codelab/gpa_demo/gpa_demo.generic.types.h"
#include "absl/types/span.h"
#include "tfhe/tfhe.h"

template <typename T>
using __TfheBaseRef = GenericEncodedRef<T,
    LweSample, LweSampleArrayDeleter, TFheGateBootstrappingSecretKeySet,
    TFheGateBootstrappingCloudKeySet, TFheGateBootstrappingParameterSet,
    ::TfheCopy, ::TfheUnencrypted, ::TfheEncrypt, ::TfheDecrypt>;

template <typename T>
using __TfheBase = GenericEncoded<T,
    LweSample, LweSampleArrayDeleter, TFheGateBootstrappingSecretKeySet,
    TFheGateBootstrappingCloudKeySet, TFheGateBootstrappingParameterSet,
    ::TfheCopy, ::TfheUnencrypted, ::TfheEncrypt, ::TfheDecrypt>;

template <typename T, unsigned... Dimensions>
using __TfheBaseArray = GenericEncodedArray<T,
    LweSample, LweSampleArrayDeleter, TFheGateBootstrappingSecretKeySet,
    TFheGateBootstrappingCloudKeySet, TFheGateBootstrappingParameterSet,
    ::TfheCopy, ::TfheUnencrypted, ::TfheEncrypt, ::TfheDecrypt, Dimensions...>;

template <typename T, unsigned... Dimensions>
using __TfheBaseArrayRef = GenericEncodedArrayRef<T,
    LweSample, LweSampleArrayDeleter, TFheGateBootstrappingSecretKeySet,
    TFheGateBootstrappingCloudKeySet, TFheGateBootstrappingParameterSet,
    ::TfheCopy, ::TfheUnencrypted, ::TfheEncrypt, ::TfheDecrypt, Dimensions...>;


#ifndef _CALCULATOR_TFHE_ENCRYPTED
#define _CALCULATOR_TFHE_ENCRYPTED
template <>
class TfheRef<Calculator> : public __TfheBaseRef<Calculator> {
 public:
  using __TfheBaseRef<Calculator>::__TfheBaseRef;

  TfheRef(const __TfheBaseRef<Calculator>& rhs)
      : TfheRef<Calculator>(const_cast<LweSample*>(rhs.get().data()), rhs.length(), rhs.bk()) {}
};

template <>
class Tfhe<Calculator> : public __TfheBase<Calculator> {
 public:
  Tfhe(const TFheGateBootstrappingParameterSet* params)
      : __TfheBase<Calculator>(new_gate_bootstrapping_ciphertext_array(
                           Tfhe<Calculator>::element_bit_width(), params),
                       1, LweSampleArrayDeleter(Tfhe<Calculator>::element_bit_width()),
                       params),
        params_(params) {}

  Tfhe<Calculator>& operator=(const TfheRef<Calculator> rhs) {
    ::TfheCopy(rhs.get(), params_, this->get());
    return *this;
  }

  operator const TfheRef<Calculator>() const& {
    return TfheRef<Calculator>(const_cast<LweSample*>(get().data()), this->length(), this->bk());
  }
  operator TfheRef<Calculator>() & {
    return TfheRef<Calculator>(const_cast<LweSample*>(get().data()), this->length(), this->bk());
  }

  static Tfhe<Calculator> Unencrypted(Calculator value,
                              const TFheGateBootstrappingCloudKeySet* key) {
    Tfhe<Calculator> plaintext(key->params);
    plaintext.SetUnencrypted(value, key);
    return plaintext;
  }

  static Tfhe<Calculator> Encrypt(Calculator value,
                          const TFheGateBootstrappingSecretKeySet* key) {
    Tfhe<Calculator> ciphertext(key->params);
    ciphertext.SetEncrypted(value, key);
    return ciphertext;
  }

 private:
  const TFheGateBootstrappingParameterSet* params_;
};

template <>
class TfheArray<Calculator> : public __TfheBaseArray<Calculator> {
 public:
  TfheArray(size_t length, const TFheGateBootstrappingParameterSet* params)
      : __TfheBaseArray<Calculator>(
            new_gate_bootstrapping_ciphertext_array(
                Tfhe<Calculator>::element_bit_width() * length, params),
            length,
            LweSampleArrayDeleter(Tfhe<Calculator>::element_bit_width() * length),
            params) {}

  static TfheArray<Calculator> Unencrypted(
     absl::Span<const Calculator> plaintext,
     const TFheGateBootstrappingCloudKeySet* key) {
    TfheArray<Calculator> shared_value(plaintext.length(), key->params);
    shared_value.SetUnencrypted(plaintext.data(), plaintext.length(), key);
    return shared_value;
  }

  static TfheArray<Calculator> Encrypt(
      absl::Span<const Calculator> plaintext,
      const TFheGateBootstrappingSecretKeySet* key) {
    TfheArray<Calculator> private_value(plaintext.length(), key->params);
    private_value.SetEncrypted(plaintext.data(), plaintext.length(), key);
    return private_value;
  }


};

template <unsigned D1>
class TfheArray<Calculator, D1> : public __TfheBaseArray<Calculator, D1> {
 public:
  TfheArray(const TFheGateBootstrappingParameterSet* params)
      : __TfheBaseArray<Calculator, D1>(
            new_gate_bootstrapping_ciphertext_array(
                Tfhe<Calculator>::element_bit_width() * D1, params),
            D1, LweSampleArrayDeleter(Tfhe<Calculator>::element_bit_width() * D1),
            params) {}

  static TfheArray<Calculator, D1> Unencrypted(
     absl::Span<const Calculator> plaintext,
     const TFheGateBootstrappingCloudKeySet* key) {
    XLS_CHECK_EQ(plaintext.length(), D1);
    TfheArray<Calculator, D1> shared_value(key->params);
    shared_value.SetUnencrypted(plaintext.data(), key);
    return shared_value;
  }

  static TfheArray<Calculator, D1> Encrypt(
      absl::Span<const Calculator> plaintext,
      const TFheGateBootstrappingSecretKeySet* key) {
    XLS_CHECK_EQ(plaintext.length(), D1);
    TfheArray<Calculator, D1> private_value(key->params);
    private_value.SetEncrypted(plaintext.data(), key);
    return private_value;
  }


};

template <unsigned D1, unsigned... Dimensions>
class TfheArray<Calculator, D1, Dimensions...> : public __TfheBaseArray<Calculator, D1, Dimensions...> {
 public:
  TfheArray(const TFheGateBootstrappingParameterSet* params)
      : __TfheBaseArray<Calculator, D1, Dimensions...>(
            new_gate_bootstrapping_ciphertext_array(
                Tfhe<Calculator>::element_bit_width() *
                    __TfheBaseArray<Calculator, D1, Dimensions...>::VOLUME,
                    params),
            __TfheBaseArray<Calculator, D1, Dimensions...>::VOLUME,
            LweSampleArrayDeleter(Tfhe<Calculator>::element_bit_width() *
                                  __TfheBaseArray<Calculator, D1, Dimensions...>::VOLUME),
            params) {}

  TfheArrayRef<Calculator, Dimensions...> operator[](size_t pos) {
    auto ref = this->__TfheBaseArray<Calculator, D1, Dimensions...>::operator[](pos);
    return TfheArrayRef<Calculator, Dimensions...>(ref);
  }
};

template <>
class TfheArrayRef<Calculator> : public __TfheBaseArrayRef<Calculator> {
 public:
  using __TfheBaseArrayRef<Calculator>::__TfheBaseArrayRef;
  TfheArrayRef(const __TfheBaseArrayRef<Calculator>& rhs)
      : TfheArrayRef<Calculator>(const_cast<LweSample*>(rhs.get().data()), rhs.length(), rhs.bk()) {
  }
  TfheArrayRef(const __TfheBaseArray<Calculator>& rhs)
      : TfheArrayRef<Calculator>(const_cast<LweSample*>(rhs.get().data()), rhs.length(), rhs.bk()) {
  }

  using __TfheBaseArrayRef<Calculator>::get;
};

template <unsigned D1>
class TfheArrayRef<Calculator, D1> : public __TfheBaseArrayRef<Calculator, D1> {
 public:
  using __TfheBaseArrayRef<Calculator, D1>::__TfheBaseArrayRef;
  TfheArrayRef(const __TfheBaseArrayRef<Calculator, D1>& rhs)
      : TfheArrayRef<Calculator, D1>(const_cast<LweSample*>(rhs.get().data()), rhs.length(),
                             rhs.bk()) {
  }
  TfheArrayRef(const __TfheBaseArray<Calculator, D1>& rhs)
      : TfheArrayRef<Calculator, D1>(const_cast<LweSample*>(rhs.get().data()), rhs.length(),
                             rhs.bk()) {
  }
  TfheArrayRef(const __TfheBaseArray<Calculator>& rhs)
      : TfheArrayRef<Calculator, D1>(const_cast<LweSample*>(rhs.get().data()), rhs.length(),
                             rhs.bk()) {
    XLS_CHECK_GE(rhs.length(), D1);
  }
  using __TfheBaseArrayRef<Calculator, D1>::get;
};

template <unsigned D1, unsigned... Dimensions>
class TfheArrayRef<Calculator, D1, Dimensions...> : public __TfheBaseArrayRef<Calculator, D1, Dimensions...> {
 public:
  using __TfheBaseArrayRef<Calculator, D1, Dimensions...>::__TfheBaseArrayRef;
  // Use the VOLUME constant instead of length().  The former gives the total
  // volume of the underlying array (accounting for all dimensions), while the
  // former gives the length of the first level of the array (e.g.,
  // Type[4][3][2] will have VOLUME = 24 and length() == 4.
  TfheArrayRef(const __TfheBaseArrayRef<Calculator, D1, Dimensions...>& rhs)
      : TfheArrayRef<Calculator, D1, Dimensions...>(const_cast<LweSample*>(rhs.get().data()),
                       __TfheBaseArrayRef<Calculator, D1, Dimensions...>::VOLUME,
                       rhs.bk()) {}
  TfheArrayRef(const __TfheBaseArray<Calculator, D1, Dimensions...>& rhs)
      : TfheArrayRef<Calculator, D1, Dimensions...>(const_cast<LweSample*>(rhs.get().data()),
                       __TfheBaseArray<Calculator, D1, Dimensions...>::VOLUME,
                       rhs.bk()) {}

  TfheArrayRef<Calculator, Dimensions...> operator[](size_t pos) {
    auto ref = this->__TfheBaseArrayRef<Calculator, D1, Dimensions...>::operator[](pos);
    return TfheArrayRef<Calculator, Dimensions...>(ref);
  }

  using __TfheBaseArrayRef<Calculator, D1, Dimensions...>::get;
};
#endif  // _CALCULATOR_TFHE_ENCRYPTED

#endif//GENERATED_BAZEL_OUT_K8_OPT_BIN_TRANSPILER_CODELAB_GPA_DEMO_GPA_DEMO_TFHE_TYPES_H