#ifndef GENERATED_BAZEL_OUT_K8_OPT_BIN_TRANSPILER_CODELAB_GPA_DEMO_GPA_DEMO_GENERIC_TYPES_H
#define GENERATED_BAZEL_OUT_K8_OPT_BIN_TRANSPILER_CODELAB_GPA_DEMO_GPA_DEMO_GENERIC_TYPES_H

#include <cstdint>
#include <memory>

#include "xls/common/logging/logging.h"
#include "absl/types/span.h"
#include "transpiler/common_runner.h"
#include "transpiler/data/cleartext_value.h"
#include "transpiler/data/generic_value.h"
#include "transpiler/codelab/gpa_demo/calculator.h"


#ifndef _CALCULATOR_GENERIC_ENCODED
#define _CALCULATOR_GENERIC_ENCODED
template <class Sample, class SampleArrayDeleter, class SecretKey,
          class PublicKey, class BootstrappingKey,
          CopyFnT<Calculator, Sample, BootstrappingKey> CopyFn,
          UnencryptedFnT<Calculator, Sample, PublicKey> UnencryptedFn,
          EncryptFnT<Calculator, Sample, SecretKey> EncryptFn,
          DecryptFnT<Calculator, Sample, SecretKey> DecryptFn>
class GenericEncodedRef<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                        BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn,
                        DecryptFn> {
 public:
  GenericEncodedRef(Sample* data, size_t length, const BootstrappingKey* bk = nullptr)
      : length_(length), data_(data), bk_(bk) {}

  GenericEncodedRef& operator=(const GenericEncodedRef& rhs) {
    XLS_CHECK_EQ(length_, rhs.length_);
    XLS_CHECK_EQ(bit_width(), rhs.bit_width());
    CopyFn(absl::MakeConstSpan(rhs.data_, bit_width()),
           bk_,
           absl::MakeSpan(data_, bit_width()));
    return *this;
  }

  // We set values here directly, instead of using EncodedValue, since
  // EncodedValue types own their arrays, whereas we'd need to own them here as
  // contiguously-allocated chunks. (We could modify them to use borrowed data,
  // but it'd be more work than this). For structure types, though, we do
  // enable setting on "borrowed" data to enable recursive setting.
  void SetUnencrypted(const Calculator& value, const PublicKey* key, size_t elem = 0) {
    SetUnencryptedInternal(value, key, data_ + elem * element_bit_width());
  }

  void SetEncrypted(const Calculator& value, const SecretKey* key, size_t elem = 0) {
    SetEncryptedInternal(value, key, data_ + elem * element_bit_width());
  }

  Calculator Decrypt(const SecretKey* key, size_t elem = 0) const {
    Calculator result;
    DecryptInternal(key, data_ + elem * element_bit_width(), &result);
    return result;
  }

  static void BorrowedSetUnencrypted(const Calculator& value, const PublicKey* key,
                                     Sample* data) {
    SetUnencryptedInternal(value, key, data);
  }

  static void BorrowedSetEncrypted(const Calculator& value, const SecretKey* key,
                                   Sample* data) {
    SetEncryptedInternal(value, key, data);
  }

  static void BorrowedDecrypt(const SecretKey* key, Sample* data, Calculator* result) {
    DecryptInternal(key, data, result);
  }

  absl::Span<Sample> get() { return absl::MakeSpan(data_, bit_width()); }
  absl::Span<const Sample> get() const {
    return absl::MakeConstSpan(data_, bit_width());
  }

  size_t length() const { return length_; }
  size_t bit_width() const { return length_ * element_bit_width(); }
  static constexpr size_t element_bit_width() { return element_bit_width_; }
  
  const BootstrappingKey* bk() const { return bk_; }

 private:
  static constexpr const size_t element_bit_width_ = 0;
  static void SetUnencryptedInternal(const Calculator& value, const PublicKey* key,
                                     Sample* data) {
    if (GetStructEncodeOrder() == StructEncodeOrder::REVERSE) {

    } else {

    }
  }

  static void SetEncryptedInternal(const Calculator& value, const SecretKey* key,
                                   Sample* data) {
    if (GetStructEncodeOrder() == StructEncodeOrder::REVERSE) {

    } else {

    }
  }

  static void DecryptInternal(const SecretKey* key, Sample* data,
                              Calculator* result){    if (GetStructEncodeOrder() == StructEncodeOrder::REVERSE) {

    } else {

    }}

  size_t length_;
  Sample* data_;
 protected:
  const BootstrappingKey* bk_;
};

template <class Sample, class SampleArrayDeleter, class SecretKey,
          class PublicKey, class BootstrappingKey,
          CopyFnT<Calculator, Sample, BootstrappingKey> CopyFn,
          UnencryptedFnT<Calculator, Sample, PublicKey> UnencryptedFn,
          EncryptFnT<Calculator, Sample, SecretKey> EncryptFn,
          DecryptFnT<Calculator, Sample, SecretKey> DecryptFn>
class GenericEncoded<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                     BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn,
                     DecryptFn> {
 public:
  GenericEncoded(const Calculator& value, const PublicKey* key,
                 const BootstrappingKey* bk = nullptr)
      : bk_(bk) {
    SetUnencrypted(value, key);
  }

  GenericEncoded(Sample* data, size_t length, SampleArrayDeleter deleter,
                 const BootstrappingKey* bk)
      : length_(length), data_(data, deleter),
        bk_(bk) {}

  GenericEncoded(GenericEncoded<Calculator, Sample, SampleArrayDeleter, SecretKey,
                                PublicKey, BootstrappingKey, CopyFn,
                                UnencryptedFn, EncryptFn, DecryptFn>&&) =
      default;

  operator const GenericEncodedRef<
      Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey, BootstrappingKey,
      CopyFn, UnencryptedFn, EncryptFn, DecryptFn>() const& {
    return GenericEncodedRef<Calculator, Sample, SampleArrayDeleter, SecretKey,
                             PublicKey, BootstrappingKey, CopyFn, UnencryptedFn,
                             EncryptFn, DecryptFn>(data_.get(), this->length(),
                                                   bk_);
  }
  operator GenericEncodedRef<Calculator, Sample, SampleArrayDeleter, SecretKey,
                             PublicKey, BootstrappingKey, CopyFn, UnencryptedFn,
                             EncryptFn, DecryptFn>() & {
    return GenericEncodedRef<Calculator, Sample, SampleArrayDeleter, SecretKey,
                             PublicKey, BootstrappingKey, CopyFn, UnencryptedFn,
                             EncryptFn, DecryptFn>(data_.get(), this->length(),
                                                   bk_);
  }

  // We set values here directly, instead of using EncodedValue, since
  // EncodedValue types own their arrays, whereas we'd need to own them here as
  // contiguously-allocated chunks. (We could modify them to use borrowed data,
  // but it'd be more work than this). For structure types, though, we do
  // enable setting on "borrowed" data to enable recursive setting.
  void SetUnencrypted(const Calculator& value, const PublicKey* key, size_t elem = 0) {
    SetUnencryptedInternal(value, key,
                           data_.get() + elem * element_bit_width());
  }

  void SetEncrypted(const Calculator& value, const SecretKey* key, size_t elem = 0) {
    XLS_CHECK(elem < this->length());
    SetEncryptedInternal(value, key, data_.get() + elem * element_bit_width());
  }

  Calculator Decrypt(const SecretKey* key, size_t elem = 0) const {
    XLS_CHECK(elem < this->length());
    Calculator result;
    DecryptInternal(key, data_.get() + elem * element_bit_width(), &result);
    return result;
  }

  static void BorrowedSetUnencrypted(const Calculator& value, Sample* data,
                                     const PublicKey* key) {
    SetUnencryptedInternal(value, key, data);
  }

  static void BorrowedSetEncrypted(const Calculator& value, Sample* data,
                                   const SecretKey* key) {
    SetEncryptedInternal(value, key, data);
  }

  static void BorrowedDecrypt(Sample* data, Calculator* result, const SecretKey* key) {
    DecryptInternal(key, data, result);
  }

  absl::Span<Sample> get() { return absl::MakeSpan(data_.get(), bit_width()); }
  absl::Span<const Sample> get() const {
    return absl::MakeConstSpan(data_.get(), bit_width());
  }

  size_t length() const { return length_; }
  size_t bit_width() const { return length_ * element_bit_width(); }
  static constexpr size_t element_bit_width() { return element_bit_width_; }

  const BootstrappingKey* bk() const { return bk_; }

 private:
  static constexpr const size_t element_bit_width_ = 0;

  static void SetUnencryptedInternal(const Calculator& value, const PublicKey* key,
                                     Sample* data) {
        if (GetStructEncodeOrder() == StructEncodeOrder::REVERSE) {

    } else {

    }
  }

  static void SetEncryptedInternal(const Calculator& value, const SecretKey* key,
                                   Sample* data) {
        if (GetStructEncodeOrder() == StructEncodeOrder::REVERSE) {

    } else {

    }
  }

  static void DecryptInternal(const SecretKey* key, Sample* data,
                              Calculator* result){    if (GetStructEncodeOrder() == StructEncodeOrder::REVERSE) {

    } else {

    }}

  size_t length_;
  std::unique_ptr<Sample[], SampleArrayDeleter> data_;
protected:
  const BootstrappingKey* bk_;
};

template <class Sample, class SampleArrayDeleter, class SecretKey,
          class PublicKey, class BootstrappingKey,
          CopyFnT<Calculator, Sample, BootstrappingKey> CopyFn,
          UnencryptedFnT<Calculator, Sample, PublicKey> UnencryptedFn,
          EncryptFnT<Calculator, Sample, SecretKey> EncryptFn,
          DecryptFnT<Calculator, Sample, SecretKey> DecryptFn>
class GenericEncodedArray<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                            BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn,
                            DecryptFn>
    : public GenericEncoded<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                              BootstrappingKey, CopyFn, UnencryptedFn,
                              EncryptFn, DecryptFn> {
 public:
  using GenericEncoded<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                         BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn,
                         DecryptFn>::GenericEncoded;

  operator const GenericEncodedArrayRef<Calculator,
      Sample, SampleArrayDeleter, SecretKey, PublicKey, BootstrappingKey,
      CopyFn, UnencryptedFn, EncryptFn, DecryptFn>() const& {
    return GenericEncodedArrayRef<Calculator, Sample, SampleArrayDeleter, SecretKey,
                                    PublicKey, BootstrappingKey, CopyFn,
                                    UnencryptedFn, EncryptFn, DecryptFn>(
        this->get(), this->length(), this->bk_);
  }
  operator GenericEncodedArrayRef<Calculator, Sample, SampleArrayDeleter, SecretKey,
                                    PublicKey, BootstrappingKey, CopyFn,
                                    UnencryptedFn, EncryptFn, DecryptFn>() & {
    return GenericEncodedArrayRef<Calculator, Sample, SampleArrayDeleter, SecretKey,
                                    PublicKey, BootstrappingKey, CopyFn,
                                    UnencryptedFn, EncryptFn, DecryptFn>(
        this->get(), this->length(), this->bk_);
  }

  template <unsigned D1>
  operator const GenericEncodedArrayRef<Calculator,
      Sample, SampleArrayDeleter, SecretKey, PublicKey, BootstrappingKey,
      CopyFn, UnencryptedFn, EncryptFn, DecryptFn, D1>() const& {
    return GenericEncodedArrayRef<Calculator, Sample, SampleArrayDeleter, SecretKey,
                                    PublicKey, BootstrappingKey, CopyFn,
                                    UnencryptedFn, EncryptFn, DecryptFn, D1>(
        this->get(), this->length(), this->bk_);
  }
  template <unsigned D1>
  operator GenericEncodedArrayRef<Calculator, Sample, SampleArrayDeleter, SecretKey,
                                    PublicKey, BootstrappingKey, CopyFn,
                                    UnencryptedFn, EncryptFn, DecryptFn, D1>() & {
    return GenericEncodedArrayRef<Calculator, Sample, SampleArrayDeleter, SecretKey,
                                    PublicKey, BootstrappingKey, CopyFn,
                                    UnencryptedFn, EncryptFn, DecryptFn, D1>(
        this->get(), this->length(), this->bk_);
  }

  // We set values here directly, instead of using EncodedValue, since
  // EncodedValue types own their arrays, whereas we'd need to own them here as
  // contiguously-allocated chunks. (We could modify them to use borrowed data,
  // but it'd be more work than this). For structure types, though, we do
  // enable setting on "borrowed" data to enable recursive setting.
  void SetUnencrypted(const Calculator* value, size_t len, const PublicKey* key) {
    XLS_CHECK(this->length() >= len);
    for (size_t i = 0; i < len; i++) {
      GenericEncoded<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                       BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn,
                       DecryptFn>::SetUnencrypted(value[i], key, i);
    }
  }

  void SetEncrypted(const Calculator* value, size_t len, const SecretKey* key) {
    XLS_CHECK(this->length() >= len);
    for (size_t i = 0; i < len; i++) {
      GenericEncoded<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                       BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn,
                       DecryptFn>::SetEncrypted(value[i], key, i);
    }
  }

  void SetEncrypted(absl::Span<const Calculator> values, const SecretKey* key) {
    XLS_CHECK(this->length() >= values.size());
    for (size_t i = 0; i < values.size(); i++) {
      GenericEncoded<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                       BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn,
                       DecryptFn>::SetEncrypted(values[i], key, i);
    }
  }

  void Decrypt(Calculator* result, size_t len, const SecretKey* key) const {
    XLS_CHECK(len >= this->length());
    for (size_t i = 0; i < this->length(); i++) {
      result[i] =
          GenericEncoded<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                           BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn,
                           DecryptFn>::Decrypt(key, i);
    }
  }

  absl::FixedArray<Calculator> Decrypt(const SecretKey* key) const {
    absl::FixedArray<Calculator> plaintext(this->length());
    Decrypt(plaintext.data(), this->length(), key);
    return plaintext;
  }

  using GenericEncoded<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                         BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn, DecryptFn>::get;

  GenericEncodedRef<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                      BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn,
                      DecryptFn>
  operator[](size_t pos) {
    XLS_CHECK(pos < this->length());
    auto span = this->get();
    return GenericEncodedRef<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                               BootstrappingKey, CopyFn, UnencryptedFn,
                               EncryptFn, DecryptFn>(span.data() + pos * 0, 1,
                                                     this->bk_);
  }
};

template <class Sample, class SampleArrayDeleter, class SecretKey,
          class PublicKey, class BootstrappingKey,
          CopyFnT<Calculator, Sample, BootstrappingKey> CopyFn,
          UnencryptedFnT<Calculator, Sample, PublicKey> UnencryptedFn,
          EncryptFnT<Calculator, Sample, SecretKey> EncryptFn,
          DecryptFnT<Calculator, Sample, SecretKey> DecryptFn, unsigned D1>
class GenericEncodedArray<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                            BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn,
                            DecryptFn, D1>
    : public GenericEncoded<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                              BootstrappingKey, CopyFn, UnencryptedFn,
                              EncryptFn, DecryptFn> {
 public:
  using GenericEncoded<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                         BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn,
                         DecryptFn>::GenericEncoded;
  enum { VOLUME = D1 };
  using ArrayT = Calculator[D1];

  operator const GenericEncodedArrayRef<Calculator,
      Sample, SampleArrayDeleter, SecretKey, PublicKey, BootstrappingKey,
      CopyFn, UnencryptedFn, EncryptFn, DecryptFn, D1>() const& {
    return GenericEncodedArrayRef<Calculator, Sample, SampleArrayDeleter, SecretKey,
                                    PublicKey, BootstrappingKey, CopyFn,
                                    UnencryptedFn, EncryptFn, DecryptFn, D1>(
        this->get(), this->length(), this->bk_);
  }
  operator GenericEncodedArrayRef<Calculator,
      Sample, SampleArrayDeleter, SecretKey, PublicKey, BootstrappingKey,
      CopyFn, UnencryptedFn, EncryptFn, DecryptFn, D1>() & {
    return GenericEncodedArrayRef<Calculator, Sample, SampleArrayDeleter, SecretKey,
                                    PublicKey, BootstrappingKey, CopyFn,
                                    UnencryptedFn, EncryptFn, DecryptFn, D1>(
        this->get(), this->length(), this->bk_);
  }

  void SetUnencrypted(const ArrayT value, const PublicKey* key, size_t elem = 0) {
    for (size_t i = 0; i < D1; i++) {
      GenericEncoded<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                       BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn,
                       DecryptFn>::SetUnencrypted(value[i], key, elem * D1 + i);
    }
  }

  void SetEncrypted(const ArrayT value, const SecretKey* key, size_t elem = 0) {
    for (size_t i = 0; i < D1; i++) {
      GenericEncoded<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                       BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn,
                       DecryptFn>::SetEncrypted(value[i], key, elem * D1 + i);
    }
  }

  void Decrypt(ArrayT result, const SecretKey* key, size_t elem = 0) const {
    for (size_t i = 0; i < D1; i++) {
      result[i] =
          GenericEncoded<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                           BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn,
                           DecryptFn>::Decrypt(key, elem * D1 + i);
    }
  }

  absl::FixedArray<Calculator> Decrypt(const SecretKey* key) const {
    absl::FixedArray<Calculator> plaintext(this->length());
    Decrypt(plaintext.data(), key);
    return plaintext;
  }

  using GenericEncoded<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                         BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn, DecryptFn>::get;

  GenericEncodedRef<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                      BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn,
                      DecryptFn>
  operator[](size_t pos) {
    XLS_CHECK(pos < this->length());
    auto span = this->get();
    return GenericEncodedRef<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                               BootstrappingKey, CopyFn, UnencryptedFn,
                               EncryptFn, DecryptFn>(span.data() + pos * 0, 1,
                                                     this->bk_);
  }
  // The base will return the full length of the underlying array, when we want
  // to return the length of this level of the multi-dimensional array.
  size_t length() const { return D1; }
};

template <class Sample, class SampleArrayDeleter, class SecretKey,
          class PublicKey, class BootstrappingKey,
          CopyFnT<Calculator, Sample, BootstrappingKey> CopyFn,
          UnencryptedFnT<Calculator, Sample, PublicKey> UnencryptedFn,
          EncryptFnT<Calculator, Sample, SecretKey> EncryptFn,
          DecryptFnT<Calculator, Sample, SecretKey> DecryptFn, unsigned D1,
          unsigned... Dimensions>
class GenericEncodedArray<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                            BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn,
                            DecryptFn, D1, Dimensions...>
    : public GenericEncodedArray<Calculator,
          Sample, SampleArrayDeleter, SecretKey, PublicKey, BootstrappingKey,
          CopyFn, UnencryptedFn, EncryptFn, DecryptFn, Dimensions...> {
 public:
  using GenericEncodedArray<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                              BootstrappingKey, CopyFn, UnencryptedFn,
                              EncryptFn, DecryptFn,
                              Dimensions...>::GenericEncodedArray;
  using LowerT =
      GenericEncodedArray<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                            BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn,
                            DecryptFn, Dimensions...>;
  using LowerArrayT = typename LowerT::ArrayT;
  enum { VOLUME = D1 * LowerT::VOLUME };
  using ArrayT = LowerArrayT[D1];

  operator const GenericEncodedArrayRef<Calculator,
      Sample, SampleArrayDeleter, SecretKey, PublicKey, BootstrappingKey,
      CopyFn, UnencryptedFn, EncryptFn, DecryptFn, D1, Dimensions...>() const& {
    return GenericEncodedArrayRef<Calculator,
        Sample, SampleArrayDeleter, SecretKey, PublicKey, BootstrappingKey,
        CopyFn, UnencryptedFn, EncryptFn, DecryptFn, D1, Dimensions...>(
        this->get(), this->length(), this->bk_);
  }
  operator GenericEncodedArrayRef<Calculator,
      Sample, SampleArrayDeleter, SecretKey, PublicKey, BootstrappingKey,
      CopyFn, UnencryptedFn, EncryptFn, DecryptFn, D1, Dimensions...>() & {
    return GenericEncodedArrayRef<Calculator,
        Sample, SampleArrayDeleter, SecretKey, PublicKey, BootstrappingKey,
        CopyFn, UnencryptedFn, EncryptFn, DecryptFn, D1, Dimensions...>(
        this->get(), this->length(), this->bk_);
  }

  void SetUnencrypted(const ArrayT value, const PublicKey* key, size_t elem = 0) {
    for (size_t i = 0; i < D1; i++) {
      GenericEncodedArray<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                            BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn, DecryptFn,
                            Dimensions...>::SetUnencrypted(value[i], key,
                                                           elem * D1 + i);
    }
  }

  void SetEncrypted(const ArrayT value, const SecretKey* key, size_t elem = 0) {
    for (size_t i = 0; i < D1; i++) {
      GenericEncodedArray<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                            BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn,
                            DecryptFn, Dimensions...>::SetEncrypted(value[i],
                                                                    key,
                                                                    elem * D1 +
                                                                        i);
    }
  }

  void Decrypt(ArrayT result, const SecretKey* key, size_t elem = 0) const {
    for (size_t i = 0; i < D1; i++) {
      GenericEncodedArray<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                            BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn,
                            DecryptFn, Dimensions...>::Decrypt(result[i], key,
                                                               elem * D1 + i);
    }
  }

  using GenericEncoded<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                         BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn, DecryptFn>::get;

  GenericEncodedArrayRef<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                           BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn,
                           DecryptFn, Dimensions...>
  operator[](size_t pos) {
    XLS_CHECK(pos < this->length());
    auto span = this->get();
    return GenericEncodedArrayRef<Calculator,
        Sample, SampleArrayDeleter, SecretKey, PublicKey, BootstrappingKey,
        CopyFn, UnencryptedFn, EncryptFn, DecryptFn, Dimensions...>(
        span.data() + pos * LowerT::VOLUME * 0, D1, this->bk_);
  }
  // The base will return the full length of the underlying array, when we want
  // to return the length of this level of the multi-dimensional array.
  size_t length() const { return D1; }
};

template <class Sample, class SampleArrayDeleter, class SecretKey,
          class PublicKey, class BootstrappingKey,
          CopyFnT<Calculator, Sample, BootstrappingKey> CopyFn,
          UnencryptedFnT<Calculator, Sample, PublicKey> UnencryptedFn,
          EncryptFnT<Calculator, Sample, SecretKey> EncryptFn,
          DecryptFnT<Calculator, Sample, SecretKey> DecryptFn>
class GenericEncodedArrayRef<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                               BootstrappingKey, CopyFn, UnencryptedFn,
                               EncryptFn, DecryptFn>
    : public GenericEncodedRef<Calculator, Sample, SampleArrayDeleter, SecretKey,
                                 PublicKey, BootstrappingKey, CopyFn,
                                 UnencryptedFn, EncryptFn, DecryptFn> {
 public:
  GenericEncodedArrayRef(Sample* data, size_t length, const BootstrappingKey* bk)
      : GenericEncodedRef<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                            BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn,
                            DecryptFn>(data, length, bk) {}

  void SetUnencrypted(const Calculator* value, size_t len, const SecretKey* key) {
    XLS_CHECK(this->length() >= len);
    for (size_t i = 0; i < len; i++) {
      GenericEncodedRef<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                          BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn,
                          DecryptFn>::SetUnencrypted(value[i], key, i);
    }
  }

  void SetEncrypted(const Calculator* value, size_t len, const SecretKey* key) {
    XLS_CHECK(this->length() >= len);
    for (size_t i = 0; i < len; i++) {
      GenericEncodedRef<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                          BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn,
                          DecryptFn>::SetEncrypted(value[i], key, i);
    }
  }

  void Decrypt(Calculator* result, size_t len, const SecretKey* key) const {
    XLS_CHECK(len >= this->length());
    for (size_t i = 0; i < this->length(); i++) {
      result[i] =
          GenericEncodedRef<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                              BootstrappingKey, CopyFn, UnencryptedFn,
                              EncryptFn, DecryptFn>::Decrypt(key, i);
    }
  }

  absl::FixedArray<Calculator> Decrypt(const SecretKey* key) const {
    absl::FixedArray<Calculator> plaintext(this->length());
    Decrypt(plaintext.data(), this->length(), key);
    return plaintext;
  }

  using GenericEncodedRef<Calculator, Sample, SampleArrayDeleter, SecretKey,
                            PublicKey, BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn, DecryptFn>::get;

  GenericEncodedRef<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                      BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn,
                      DecryptFn>
  operator[](size_t pos) {
    XLS_CHECK(pos < this->length());
    auto span = this->get();
    return GenericEncodedRef<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                               BootstrappingKey, CopyFn, UnencryptedFn,
                               EncryptFn, DecryptFn>(span.data() + pos * 0, 1,
                                                     this->bk_);
  }
};

template <class Sample, class SampleArrayDeleter, class SecretKey,
          class PublicKey, class BootstrappingKey,
          CopyFnT<Calculator, Sample, BootstrappingKey> CopyFn,
          UnencryptedFnT<Calculator, Sample, PublicKey> UnencryptedFn,
          EncryptFnT<Calculator, Sample, SecretKey> EncryptFn,
          DecryptFnT<Calculator, Sample, SecretKey> DecryptFn, unsigned D1>
class GenericEncodedArrayRef<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                               BootstrappingKey, CopyFn, UnencryptedFn,
                               EncryptFn, DecryptFn, D1>
    : public GenericEncodedRef<Calculator, Sample, SampleArrayDeleter, SecretKey,
                                 PublicKey, BootstrappingKey, CopyFn,
                                 UnencryptedFn, EncryptFn, DecryptFn> {
 public:
  enum { VOLUME = D1 };
  using ArrayT = Calculator[D1];

  GenericEncodedArrayRef(Sample* data, size_t length, const BootstrappingKey* bk)
      : GenericEncodedRef<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                            BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn,
                            DecryptFn>(data, length, bk) {}

  void SetUnencrypted(const ArrayT value, const SecretKey* key, size_t elem) {
    for (size_t i = 0; i < D1; i++) {
      GenericEncodedRef<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                          BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn,
                          DecryptFn>::SetUnencrypted(value[i], key,
                                                     elem * D1 + i);
    }
  }

  void SetEncrypted(const ArrayT value, const SecretKey* key, size_t elem) {
    for (size_t i = 0; i < D1; i++) {
      GenericEncodedRef<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                          BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn,
                          DecryptFn>::SetEncrypted(value[i], key,
                                                   elem * D1 + i);
    }
  }

  void Decrypt(ArrayT result, const SecretKey* key, size_t elem = 0) const {
    for (size_t i = 0; i < D1; i++) {
      result[i] =
          GenericEncodedRef<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                              BootstrappingKey, CopyFn, UnencryptedFn,
                              EncryptFn, DecryptFn>::Decrypt(key,
                                                             elem * D1 + i);
    }
  }

  absl::FixedArray<Calculator> Decrypt(const SecretKey* key) const {
    absl::FixedArray<Calculator> plaintext(this->length());
    Decrypt(plaintext.data(), key);
    return plaintext;
  }

  using GenericEncodedRef<Calculator, Sample, SampleArrayDeleter, SecretKey,
                            PublicKey, BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn, DecryptFn>::get;

  GenericEncodedRef<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                      BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn,
                      DecryptFn>
  operator[](size_t pos) {
    XLS_CHECK(pos < this->length());
    auto span = this->get();
    return GenericEncodedRef<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                               BootstrappingKey, CopyFn, UnencryptedFn,
                               EncryptFn, DecryptFn>(span.data() + pos * 0, 1,
                                                     this->bk_);
  }

  // The base will return the full length of the underlying array, when we want
  // to return the length of this level of the multi-dimensional array.
  size_t length() const { return D1; }
};

template <class Sample, class SampleArrayDeleter, class SecretKey,
          class PublicKey, class BootstrappingKey,
          CopyFnT<Calculator, Sample, BootstrappingKey> CopyFn,
          UnencryptedFnT<Calculator, Sample, PublicKey> UnencryptedFn,
          EncryptFnT<Calculator, Sample, SecretKey> EncryptFn,
          DecryptFnT<Calculator, Sample, SecretKey> DecryptFn, unsigned D1,
          unsigned... Dimensions>
class GenericEncodedArrayRef<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                               BootstrappingKey, CopyFn, UnencryptedFn,
                               EncryptFn, DecryptFn, D1, Dimensions...>
    : public GenericEncodedArrayRef<Calculator,
          Sample, SampleArrayDeleter, SecretKey, PublicKey, BootstrappingKey,
          CopyFn, UnencryptedFn, EncryptFn, DecryptFn, Dimensions...> {
 public:
  using LowerT =
      GenericEncodedArray<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                            BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn,
                            DecryptFn, Dimensions...>;
  using LowerArrayT = typename LowerT::ArrayT;
  enum { VOLUME = D1 * LowerT::VOLUME };
  using ArrayT = LowerArrayT[D1];

  GenericEncodedArrayRef(Sample* data, size_t length, const BootstrappingKey* bk)
      : GenericEncodedArrayRef<Calculator,
            Sample, SampleArrayDeleter, SecretKey, PublicKey, BootstrappingKey,
            CopyFn, UnencryptedFn, EncryptFn, DecryptFn, Dimensions...>(
            data, length, bk) {}

  void SetUnencrypted(const ArrayT value, const SecretKey* key, size_t elem = 0) {
    for (size_t i = 0; i < D1; i++) {
      GenericEncodedArrayRef<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                               BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn, DecryptFn,
                               Dimensions...>::SetUnencrypted(value[i], key,
                                                              elem * D1 + i);
    }
  }

  void SetEncrypted(const ArrayT value, const SecretKey* key, size_t elem = 0) {
    for (size_t i = 0; i < D1; i++) {
      GenericEncodedArrayRef<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                               BootstrappingKey, CopyFn, UnencryptedFn,
                               EncryptFn, DecryptFn,
                               Dimensions...>::SetEncrypted(value[i], key,
                                                            elem * D1 + i);
    }
  }

  void Decrypt(ArrayT result, const SecretKey* key, size_t elem = 0) const {
    for (size_t i = 0; i < D1; i++) {
      GenericEncodedArrayRef<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                               BootstrappingKey, CopyFn, UnencryptedFn,
                               EncryptFn, DecryptFn,
                               Dimensions...>::Decrypt(result[i], key,
                                                       elem * D1 + i);
    }
  }

  using GenericEncodedArrayRef<Calculator, Sample, SampleArrayDeleter, SecretKey,
                            PublicKey, BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn, DecryptFn,
                            Dimensions...>::get;

  GenericEncodedArrayRef<Calculator, Sample, SampleArrayDeleter, SecretKey, PublicKey,
                           BootstrappingKey, CopyFn, UnencryptedFn, EncryptFn,
                           DecryptFn, Dimensions...>
  operator[](size_t pos) {
    XLS_CHECK(pos < this->length());
    auto span = this->get();
    return GenericEncodedArrayRef<Calculator,
        Sample, SampleArrayDeleter, SecretKey, PublicKey, BootstrappingKey,
        CopyFn, UnencryptedFn, EncryptFn, DecryptFn, Dimensions...>(
        span.data() + pos * LowerT::VOLUME * 0, D1, this->bk_);
  }
  // The base will return the full length of the underlying array, when we want
  // to return the length of this level of the multi-dimensional array.
  size_t length() const { return D1; }
};
#endif  // _CALCULATOR_GENERIC_ENCODED

#endif//GENERATED_BAZEL_OUT_K8_OPT_BIN_TRANSPILER_CODELAB_GPA_DEMO_GPA_DEMO_GENERIC_TYPES_H