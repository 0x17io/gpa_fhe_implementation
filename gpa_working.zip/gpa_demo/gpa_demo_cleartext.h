#ifndef BAZEL_OUT_K8_OPT_BIN_TRANSPILER_CODELAB_GPA_DEMO_GPA_DEMO_CLEARTEXT_H
#define BAZEL_OUT_K8_OPT_BIN_TRANSPILER_CODELAB_GPA_DEMO_GPA_DEMO_CLEARTEXT_H

#include "transpiler/codelab/gpa_demo/gpa_demo_cleartext.types.h"
#include "absl/status/status.h"
#include "absl/types/span.h"
#include "transpiler/data/cleartext_data.h"

absl::Status my_package_UNSAFE(absl::Span<bool> result, absl::Span<bool> calc, absl::Span<const bool> w, absl::Span<const bool> x, absl::Span<const bool> y, absl::Span<const bool> z);
absl::Status my_package(EncodedRef<signed short> result, EncodedRef<Calculator> calc, const EncodedRef<signed short> w, const EncodedRef<signed short> x, const EncodedRef<signed short> y, const EncodedRef<signed short> z) {
  return my_package_UNSAFE(result.get(), calc.get(), w.get(), x.get(), y.get(), z.get());
}
#endif  // BAZEL_OUT_K8_OPT_BIN_TRANSPILER_CODELAB_GPA_DEMO_GPA_DEMO_CLEARTEXT_H
