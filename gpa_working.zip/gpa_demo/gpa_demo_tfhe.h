#ifndef BAZEL_OUT_K8_OPT_BIN_TRANSPILER_CODELAB_GPA_DEMO_GPA_DEMO_TFHE_H
#define BAZEL_OUT_K8_OPT_BIN_TRANSPILER_CODELAB_GPA_DEMO_GPA_DEMO_TFHE_H

#include "transpiler/codelab/gpa_demo/gpa_demo_tfhe.types.h"
#include "absl/status/status.h"
#include "absl/types/span.h"
#include "transpiler/data/tfhe_data.h"
#include "tfhe/tfhe.h"
#include "tfhe/tfhe_io.h"

absl::Status my_package_UNSAFE(absl::Span<LweSample> result, absl::Span<LweSample> calc, absl::Span<const LweSample> w, absl::Span<const LweSample> x, absl::Span<const LweSample> y, absl::Span<const LweSample> z, const TFheGateBootstrappingCloudKeySet* bk);

absl::Status my_package(TfheRef<signed short> result, TfheRef<Calculator> calc, const TfheRef<signed short> w, const TfheRef<signed short> x, const TfheRef<signed short> y, const TfheRef<signed short> z,
 const TFheGateBootstrappingCloudKeySet* bk) {
  return my_package_UNSAFE(result.get(), calc.get(), w.get(), x.get(), y.get(), z.get(), bk);
}
#endif  // BAZEL_OUT_K8_OPT_BIN_TRANSPILER_CODELAB_GPA_DEMO_GPA_DEMO_TFHE_H
