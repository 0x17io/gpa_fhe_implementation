#include <unordered_map>

#include "absl/status/status.h"
#include "absl/types/span.h"
#include "transpiler/common_runner.h"

static StructReverseEncodeOrderSetter ORDER;

absl::Status my_package_UNSAFE(absl::Span<bool> result, absl::Span<bool> calc, absl::Span<const bool> w, absl::Span<const bool> x, absl::Span<const bool> y, absl::Span<const bool> z) {
  std::unordered_map<int, bool> temp_nodes;

  temp_nodes[2096] = w[1];

  temp_nodes[2112] = x[1];

  temp_nodes[2128] = y[1];

  temp_nodes[2144] = z[1];

  temp_nodes[2159] = temp_nodes[2096] && temp_nodes[2112];

  temp_nodes[2163] = temp_nodes[2128] && temp_nodes[2144];

  temp_nodes[2161] = temp_nodes[2096] || temp_nodes[2112];

  temp_nodes[2160] = !temp_nodes[2159];

  temp_nodes[2165] = temp_nodes[2128] || temp_nodes[2144];

  temp_nodes[2164] = !temp_nodes[2163];

  temp_nodes[2162] = temp_nodes[2161] && temp_nodes[2160];

  temp_nodes[2095] = w[0];

  temp_nodes[2166] = temp_nodes[2165] && temp_nodes[2164];

  temp_nodes[2127] = y[0];

  temp_nodes[2097] = w[2];

  temp_nodes[2113] = x[2];

  temp_nodes[2129] = y[2];

  temp_nodes[2145] = z[2];

  temp_nodes[2111] = x[0];

  temp_nodes[2190] = temp_nodes[2162] && temp_nodes[2095];

  temp_nodes[2143] = z[0];

  temp_nodes[2194] = temp_nodes[2166] && temp_nodes[2127];

  temp_nodes[2173] = temp_nodes[2097] && temp_nodes[2113];

  temp_nodes[2168] = temp_nodes[2162] && temp_nodes[2095];

  temp_nodes[2178] = temp_nodes[2129] && temp_nodes[2145];

  temp_nodes[2171] = temp_nodes[2166] && temp_nodes[2127];

  temp_nodes[2183] = temp_nodes[2095] && temp_nodes[2111];

  temp_nodes[2191] = temp_nodes[2190] && temp_nodes[2111];

  temp_nodes[2184] = temp_nodes[2127] && temp_nodes[2143];

  temp_nodes[2195] = temp_nodes[2194] && temp_nodes[2143];

  temp_nodes[2098] = w[3];

  temp_nodes[2114] = x[3];

  temp_nodes[2175] = temp_nodes[2097] || temp_nodes[2113];

  temp_nodes[2174] = !temp_nodes[2173];

  temp_nodes[2167] = temp_nodes[2096] && temp_nodes[2112];

  temp_nodes[2169] = temp_nodes[2168] && temp_nodes[2111];

  temp_nodes[2130] = y[3];

  temp_nodes[2146] = z[3];

  temp_nodes[2180] = temp_nodes[2129] || temp_nodes[2145];

  temp_nodes[2179] = !temp_nodes[2178];

  temp_nodes[2170] = temp_nodes[2128] && temp_nodes[2144];

  temp_nodes[2172] = temp_nodes[2171] && temp_nodes[2143];

  temp_nodes[2189] = temp_nodes[2162] || temp_nodes[2183];

  temp_nodes[2192] = !temp_nodes[2191];

  temp_nodes[2193] = temp_nodes[2166] || temp_nodes[2184];

  temp_nodes[2196] = !temp_nodes[2195];

  temp_nodes[2197] = temp_nodes[2098] && temp_nodes[2114];

  temp_nodes[2176] = temp_nodes[2175] && temp_nodes[2174];

  temp_nodes[2177] = temp_nodes[2167] || temp_nodes[2169];

  temp_nodes[2202] = temp_nodes[2130] && temp_nodes[2146];

  temp_nodes[2181] = temp_nodes[2180] && temp_nodes[2179];

  temp_nodes[2182] = temp_nodes[2170] || temp_nodes[2172];

  temp_nodes[2211] = temp_nodes[2189] && temp_nodes[2192];

  temp_nodes[2212] = temp_nodes[2193] && temp_nodes[2196];

  temp_nodes[2099] = w[4];

  temp_nodes[2115] = x[4];

  temp_nodes[2199] = temp_nodes[2098] || temp_nodes[2114];

  temp_nodes[2198] = !temp_nodes[2197];

  temp_nodes[2185] = temp_nodes[2097] && temp_nodes[2113];

  temp_nodes[2186] = temp_nodes[2176] && temp_nodes[2177];

  temp_nodes[2131] = y[4];

  temp_nodes[2147] = z[4];

  temp_nodes[2204] = temp_nodes[2130] || temp_nodes[2146];

  temp_nodes[2203] = !temp_nodes[2202];

  temp_nodes[2187] = temp_nodes[2129] && temp_nodes[2145];

  temp_nodes[2188] = temp_nodes[2181] && temp_nodes[2182];

  temp_nodes[2219] = temp_nodes[2211] && temp_nodes[2212];

  temp_nodes[2237] = temp_nodes[2095] && temp_nodes[2111];

  temp_nodes[2220] = temp_nodes[2099] && temp_nodes[2115];

  temp_nodes[2200] = temp_nodes[2199] && temp_nodes[2198];

  temp_nodes[2201] = temp_nodes[2185] || temp_nodes[2186];

  temp_nodes[2225] = temp_nodes[2131] && temp_nodes[2147];

  temp_nodes[2205] = temp_nodes[2204] && temp_nodes[2203];

  temp_nodes[2206] = temp_nodes[2187] || temp_nodes[2188];

  temp_nodes[2207] = temp_nodes[2176] || temp_nodes[2177];

  temp_nodes[2208] = !temp_nodes[2186];

  temp_nodes[2209] = temp_nodes[2181] || temp_nodes[2182];

  temp_nodes[2210] = !temp_nodes[2188];

  temp_nodes[2235] = temp_nodes[2211] || temp_nodes[2212];

  temp_nodes[2236] = !temp_nodes[2219];

  temp_nodes[2239] = temp_nodes[2095] || temp_nodes[2111];

  temp_nodes[2238] = !temp_nodes[2237];

  temp_nodes[2241] = temp_nodes[2127] && temp_nodes[2143];

  temp_nodes[2100] = w[5];

  temp_nodes[2116] = x[5];

  temp_nodes[2222] = temp_nodes[2099] || temp_nodes[2115];

  temp_nodes[2221] = !temp_nodes[2220];

  temp_nodes[2213] = temp_nodes[2098] && temp_nodes[2114];

  temp_nodes[2214] = temp_nodes[2200] && temp_nodes[2201];

  temp_nodes[2132] = y[5];

  temp_nodes[2148] = z[5];

  temp_nodes[2227] = temp_nodes[2131] || temp_nodes[2147];

  temp_nodes[2226] = !temp_nodes[2225];

  temp_nodes[2215] = temp_nodes[2130] && temp_nodes[2146];

  temp_nodes[2216] = temp_nodes[2205] && temp_nodes[2206];

  temp_nodes[2217] = temp_nodes[2207] && temp_nodes[2208];

  temp_nodes[2218] = temp_nodes[2209] && temp_nodes[2210];

  temp_nodes[2253] = temp_nodes[2235] && temp_nodes[2236];

  temp_nodes[2240] = temp_nodes[2239] && temp_nodes[2238];

  temp_nodes[2243] = temp_nodes[2127] || temp_nodes[2143];

  temp_nodes[2242] = !temp_nodes[2241];

  temp_nodes[2256] = temp_nodes[2100] && temp_nodes[2116];

  temp_nodes[2223] = temp_nodes[2222] && temp_nodes[2221];

  temp_nodes[2224] = temp_nodes[2213] || temp_nodes[2214];

  temp_nodes[2261] = temp_nodes[2132] && temp_nodes[2148];

  temp_nodes[2228] = temp_nodes[2227] && temp_nodes[2226];

  temp_nodes[2229] = temp_nodes[2215] || temp_nodes[2216];

  temp_nodes[2230] = temp_nodes[2200] || temp_nodes[2201];

  temp_nodes[2231] = !temp_nodes[2214];

  temp_nodes[2232] = temp_nodes[2205] || temp_nodes[2206];

  temp_nodes[2233] = !temp_nodes[2216];

  temp_nodes[2234] = temp_nodes[2217] && temp_nodes[2218];

  temp_nodes[2254] = temp_nodes[2253] && temp_nodes[2240];

  temp_nodes[2244] = temp_nodes[2243] && temp_nodes[2242];

  temp_nodes[2101] = w[6];

  temp_nodes[2117] = x[6];

  temp_nodes[2258] = temp_nodes[2100] || temp_nodes[2116];

  temp_nodes[2257] = !temp_nodes[2256];

  temp_nodes[2245] = temp_nodes[2099] && temp_nodes[2115];

  temp_nodes[2246] = temp_nodes[2223] && temp_nodes[2224];

  temp_nodes[2133] = y[6];

  temp_nodes[2149] = z[6];

  temp_nodes[2263] = temp_nodes[2132] || temp_nodes[2148];

  temp_nodes[2262] = !temp_nodes[2261];

  temp_nodes[2247] = temp_nodes[2131] && temp_nodes[2147];

  temp_nodes[2248] = temp_nodes[2228] && temp_nodes[2229];

  temp_nodes[2249] = temp_nodes[2230] && temp_nodes[2231];

  temp_nodes[2250] = temp_nodes[2232] && temp_nodes[2233];

  temp_nodes[2251] = temp_nodes[2217] || temp_nodes[2218];

  temp_nodes[2252] = !temp_nodes[2234];

  temp_nodes[2255] = temp_nodes[2254] && temp_nodes[2244];

  temp_nodes[2282] = temp_nodes[2101] && temp_nodes[2117];

  temp_nodes[2259] = temp_nodes[2258] && temp_nodes[2257];

  temp_nodes[2260] = temp_nodes[2245] || temp_nodes[2246];

  temp_nodes[2287] = temp_nodes[2133] && temp_nodes[2149];

  temp_nodes[2264] = temp_nodes[2263] && temp_nodes[2262];

  temp_nodes[2265] = temp_nodes[2247] || temp_nodes[2248];

  temp_nodes[2266] = temp_nodes[2223] || temp_nodes[2224];

  temp_nodes[2267] = !temp_nodes[2246];

  temp_nodes[2268] = temp_nodes[2228] || temp_nodes[2229];

  temp_nodes[2269] = !temp_nodes[2248];

  temp_nodes[2270] = temp_nodes[2249] && temp_nodes[2250];

  temp_nodes[2271] = temp_nodes[2251] && temp_nodes[2252];

  temp_nodes[2272] = temp_nodes[2219] || temp_nodes[2255];

  temp_nodes[2102] = w[7];

  temp_nodes[2118] = x[7];

  temp_nodes[2284] = temp_nodes[2101] || temp_nodes[2117];

  temp_nodes[2283] = !temp_nodes[2282];

  temp_nodes[2273] = temp_nodes[2100] && temp_nodes[2116];

  temp_nodes[2274] = temp_nodes[2259] && temp_nodes[2260];

  temp_nodes[2134] = y[7];

  temp_nodes[2150] = z[7];

  temp_nodes[2289] = temp_nodes[2133] || temp_nodes[2149];

  temp_nodes[2288] = !temp_nodes[2287];

  temp_nodes[2275] = temp_nodes[2132] && temp_nodes[2148];

  temp_nodes[2276] = temp_nodes[2264] && temp_nodes[2265];

  temp_nodes[2277] = temp_nodes[2266] && temp_nodes[2267];

  temp_nodes[2278] = temp_nodes[2268] && temp_nodes[2269];

  temp_nodes[2279] = temp_nodes[2249] || temp_nodes[2250];

  temp_nodes[2280] = !temp_nodes[2270];

  temp_nodes[2281] = temp_nodes[2271] && temp_nodes[2272];

  temp_nodes[2308] = temp_nodes[2102] && temp_nodes[2118];

  temp_nodes[2285] = temp_nodes[2284] && temp_nodes[2283];

  temp_nodes[2286] = temp_nodes[2273] || temp_nodes[2274];

  temp_nodes[2313] = temp_nodes[2134] && temp_nodes[2150];

  temp_nodes[2290] = temp_nodes[2289] && temp_nodes[2288];

  temp_nodes[2291] = temp_nodes[2275] || temp_nodes[2276];

  temp_nodes[2292] = temp_nodes[2259] || temp_nodes[2260];

  temp_nodes[2293] = !temp_nodes[2274];

  temp_nodes[2294] = temp_nodes[2264] || temp_nodes[2265];

  temp_nodes[2295] = !temp_nodes[2276];

  temp_nodes[2296] = temp_nodes[2277] && temp_nodes[2278];

  temp_nodes[2297] = temp_nodes[2279] && temp_nodes[2280];

  temp_nodes[2298] = temp_nodes[2234] || temp_nodes[2281];

  temp_nodes[2103] = w[8];

  temp_nodes[2119] = x[8];

  temp_nodes[2310] = temp_nodes[2102] || temp_nodes[2118];

  temp_nodes[2309] = !temp_nodes[2308];

  temp_nodes[2299] = temp_nodes[2101] && temp_nodes[2117];

  temp_nodes[2300] = temp_nodes[2285] && temp_nodes[2286];

  temp_nodes[2135] = y[8];

  temp_nodes[2151] = z[8];

  temp_nodes[2315] = temp_nodes[2134] || temp_nodes[2150];

  temp_nodes[2314] = !temp_nodes[2313];

  temp_nodes[2301] = temp_nodes[2133] && temp_nodes[2149];

  temp_nodes[2302] = temp_nodes[2290] && temp_nodes[2291];

  temp_nodes[2303] = temp_nodes[2292] && temp_nodes[2293];

  temp_nodes[2304] = temp_nodes[2294] && temp_nodes[2295];

  temp_nodes[2305] = temp_nodes[2277] || temp_nodes[2278];

  temp_nodes[2306] = !temp_nodes[2296];

  temp_nodes[2307] = temp_nodes[2297] && temp_nodes[2298];

  temp_nodes[2334] = temp_nodes[2103] && temp_nodes[2119];

  temp_nodes[2311] = temp_nodes[2310] && temp_nodes[2309];

  temp_nodes[2312] = temp_nodes[2299] || temp_nodes[2300];

  temp_nodes[2339] = temp_nodes[2135] && temp_nodes[2151];

  temp_nodes[2316] = temp_nodes[2315] && temp_nodes[2314];

  temp_nodes[2317] = temp_nodes[2301] || temp_nodes[2302];

  temp_nodes[2318] = temp_nodes[2285] || temp_nodes[2286];

  temp_nodes[2319] = !temp_nodes[2300];

  temp_nodes[2320] = temp_nodes[2290] || temp_nodes[2291];

  temp_nodes[2321] = !temp_nodes[2302];

  temp_nodes[2322] = temp_nodes[2303] && temp_nodes[2304];

  temp_nodes[2323] = temp_nodes[2305] && temp_nodes[2306];

  temp_nodes[2324] = temp_nodes[2270] || temp_nodes[2307];

  temp_nodes[2104] = w[9];

  temp_nodes[2120] = x[9];

  temp_nodes[2336] = temp_nodes[2103] || temp_nodes[2119];

  temp_nodes[2335] = !temp_nodes[2334];

  temp_nodes[2325] = temp_nodes[2102] && temp_nodes[2118];

  temp_nodes[2326] = temp_nodes[2311] && temp_nodes[2312];

  temp_nodes[2136] = y[9];

  temp_nodes[2152] = z[9];

  temp_nodes[2341] = temp_nodes[2135] || temp_nodes[2151];

  temp_nodes[2340] = !temp_nodes[2339];

  temp_nodes[2327] = temp_nodes[2134] && temp_nodes[2150];

  temp_nodes[2328] = temp_nodes[2316] && temp_nodes[2317];

  temp_nodes[2329] = temp_nodes[2318] && temp_nodes[2319];

  temp_nodes[2330] = temp_nodes[2320] && temp_nodes[2321];

  temp_nodes[2331] = temp_nodes[2303] || temp_nodes[2304];

  temp_nodes[2332] = !temp_nodes[2322];

  temp_nodes[2333] = temp_nodes[2323] && temp_nodes[2324];

  temp_nodes[2360] = temp_nodes[2104] && temp_nodes[2120];

  temp_nodes[2337] = temp_nodes[2336] && temp_nodes[2335];

  temp_nodes[2338] = temp_nodes[2325] || temp_nodes[2326];

  temp_nodes[2365] = temp_nodes[2136] && temp_nodes[2152];

  temp_nodes[2342] = temp_nodes[2341] && temp_nodes[2340];

  temp_nodes[2343] = temp_nodes[2327] || temp_nodes[2328];

  temp_nodes[2344] = temp_nodes[2311] || temp_nodes[2312];

  temp_nodes[2345] = !temp_nodes[2326];

  temp_nodes[2346] = temp_nodes[2316] || temp_nodes[2317];

  temp_nodes[2347] = !temp_nodes[2328];

  temp_nodes[2348] = temp_nodes[2329] && temp_nodes[2330];

  temp_nodes[2349] = temp_nodes[2331] && temp_nodes[2332];

  temp_nodes[2350] = temp_nodes[2296] || temp_nodes[2333];

  temp_nodes[2105] = w[10];

  temp_nodes[2121] = x[10];

  temp_nodes[2362] = temp_nodes[2104] || temp_nodes[2120];

  temp_nodes[2361] = !temp_nodes[2360];

  temp_nodes[2351] = temp_nodes[2103] && temp_nodes[2119];

  temp_nodes[2352] = temp_nodes[2337] && temp_nodes[2338];

  temp_nodes[2137] = y[10];

  temp_nodes[2153] = z[10];

  temp_nodes[2367] = temp_nodes[2136] || temp_nodes[2152];

  temp_nodes[2366] = !temp_nodes[2365];

  temp_nodes[2353] = temp_nodes[2135] && temp_nodes[2151];

  temp_nodes[2354] = temp_nodes[2342] && temp_nodes[2343];

  temp_nodes[2355] = temp_nodes[2344] && temp_nodes[2345];

  temp_nodes[2356] = temp_nodes[2346] && temp_nodes[2347];

  temp_nodes[2357] = temp_nodes[2329] || temp_nodes[2330];

  temp_nodes[2358] = !temp_nodes[2348];

  temp_nodes[2359] = temp_nodes[2349] && temp_nodes[2350];

  temp_nodes[2386] = temp_nodes[2105] && temp_nodes[2121];

  temp_nodes[2363] = temp_nodes[2362] && temp_nodes[2361];

  temp_nodes[2364] = temp_nodes[2351] || temp_nodes[2352];

  temp_nodes[2391] = temp_nodes[2137] && temp_nodes[2153];

  temp_nodes[2368] = temp_nodes[2367] && temp_nodes[2366];

  temp_nodes[2369] = temp_nodes[2353] || temp_nodes[2354];

  temp_nodes[2370] = temp_nodes[2337] || temp_nodes[2338];

  temp_nodes[2371] = !temp_nodes[2352];

  temp_nodes[2372] = temp_nodes[2342] || temp_nodes[2343];

  temp_nodes[2373] = !temp_nodes[2354];

  temp_nodes[2374] = temp_nodes[2355] && temp_nodes[2356];

  temp_nodes[2375] = temp_nodes[2357] && temp_nodes[2358];

  temp_nodes[2376] = temp_nodes[2322] || temp_nodes[2359];

  temp_nodes[2106] = w[11];

  temp_nodes[2122] = x[11];

  temp_nodes[2388] = temp_nodes[2105] || temp_nodes[2121];

  temp_nodes[2387] = !temp_nodes[2386];

  temp_nodes[2377] = temp_nodes[2104] && temp_nodes[2120];

  temp_nodes[2378] = temp_nodes[2363] && temp_nodes[2364];

  temp_nodes[2138] = y[11];

  temp_nodes[2154] = z[11];

  temp_nodes[2393] = temp_nodes[2137] || temp_nodes[2153];

  temp_nodes[2392] = !temp_nodes[2391];

  temp_nodes[2379] = temp_nodes[2136] && temp_nodes[2152];

  temp_nodes[2380] = temp_nodes[2368] && temp_nodes[2369];

  temp_nodes[2381] = temp_nodes[2370] && temp_nodes[2371];

  temp_nodes[2382] = temp_nodes[2372] && temp_nodes[2373];

  temp_nodes[2383] = temp_nodes[2355] || temp_nodes[2356];

  temp_nodes[2384] = !temp_nodes[2374];

  temp_nodes[2385] = temp_nodes[2375] && temp_nodes[2376];

  temp_nodes[2412] = temp_nodes[2106] && temp_nodes[2122];

  temp_nodes[2389] = temp_nodes[2388] && temp_nodes[2387];

  temp_nodes[2390] = temp_nodes[2377] || temp_nodes[2378];

  temp_nodes[2417] = temp_nodes[2138] && temp_nodes[2154];

  temp_nodes[2394] = temp_nodes[2393] && temp_nodes[2392];

  temp_nodes[2395] = temp_nodes[2379] || temp_nodes[2380];

  temp_nodes[2396] = temp_nodes[2363] || temp_nodes[2364];

  temp_nodes[2397] = !temp_nodes[2378];

  temp_nodes[2398] = temp_nodes[2368] || temp_nodes[2369];

  temp_nodes[2399] = !temp_nodes[2380];

  temp_nodes[2400] = temp_nodes[2381] && temp_nodes[2382];

  temp_nodes[2401] = temp_nodes[2383] && temp_nodes[2384];

  temp_nodes[2402] = temp_nodes[2348] || temp_nodes[2385];

  temp_nodes[2107] = w[12];

  temp_nodes[2123] = x[12];

  temp_nodes[2414] = temp_nodes[2106] || temp_nodes[2122];

  temp_nodes[2413] = !temp_nodes[2412];

  temp_nodes[2403] = temp_nodes[2105] && temp_nodes[2121];

  temp_nodes[2404] = temp_nodes[2389] && temp_nodes[2390];

  temp_nodes[2139] = y[12];

  temp_nodes[2155] = z[12];

  temp_nodes[2419] = temp_nodes[2138] || temp_nodes[2154];

  temp_nodes[2418] = !temp_nodes[2417];

  temp_nodes[2405] = temp_nodes[2137] && temp_nodes[2153];

  temp_nodes[2406] = temp_nodes[2394] && temp_nodes[2395];

  temp_nodes[2407] = temp_nodes[2396] && temp_nodes[2397];

  temp_nodes[2408] = temp_nodes[2398] && temp_nodes[2399];

  temp_nodes[2409] = temp_nodes[2381] || temp_nodes[2382];

  temp_nodes[2410] = !temp_nodes[2400];

  temp_nodes[2411] = temp_nodes[2401] && temp_nodes[2402];

  temp_nodes[2438] = temp_nodes[2107] && temp_nodes[2123];

  temp_nodes[2415] = temp_nodes[2414] && temp_nodes[2413];

  temp_nodes[2416] = temp_nodes[2403] || temp_nodes[2404];

  temp_nodes[2443] = temp_nodes[2139] && temp_nodes[2155];

  temp_nodes[2420] = temp_nodes[2419] && temp_nodes[2418];

  temp_nodes[2421] = temp_nodes[2405] || temp_nodes[2406];

  temp_nodes[2422] = temp_nodes[2389] || temp_nodes[2390];

  temp_nodes[2423] = !temp_nodes[2404];

  temp_nodes[2424] = temp_nodes[2394] || temp_nodes[2395];

  temp_nodes[2425] = !temp_nodes[2406];

  temp_nodes[2426] = temp_nodes[2407] && temp_nodes[2408];

  temp_nodes[2427] = temp_nodes[2409] && temp_nodes[2410];

  temp_nodes[2428] = temp_nodes[2374] || temp_nodes[2411];

  temp_nodes[2108] = w[13];

  temp_nodes[2124] = x[13];

  temp_nodes[2440] = temp_nodes[2107] || temp_nodes[2123];

  temp_nodes[2439] = !temp_nodes[2438];

  temp_nodes[2429] = temp_nodes[2106] && temp_nodes[2122];

  temp_nodes[2430] = temp_nodes[2415] && temp_nodes[2416];

  temp_nodes[2140] = y[13];

  temp_nodes[2156] = z[13];

  temp_nodes[2445] = temp_nodes[2139] || temp_nodes[2155];

  temp_nodes[2444] = !temp_nodes[2443];

  temp_nodes[2431] = temp_nodes[2138] && temp_nodes[2154];

  temp_nodes[2432] = temp_nodes[2420] && temp_nodes[2421];

  temp_nodes[2433] = temp_nodes[2422] && temp_nodes[2423];

  temp_nodes[2434] = temp_nodes[2424] && temp_nodes[2425];

  temp_nodes[2435] = temp_nodes[2407] || temp_nodes[2408];

  temp_nodes[2436] = !temp_nodes[2426];

  temp_nodes[2437] = temp_nodes[2427] && temp_nodes[2428];

  temp_nodes[2464] = temp_nodes[2108] && temp_nodes[2124];

  temp_nodes[2441] = temp_nodes[2440] && temp_nodes[2439];

  temp_nodes[2442] = temp_nodes[2429] || temp_nodes[2430];

  temp_nodes[2469] = temp_nodes[2140] && temp_nodes[2156];

  temp_nodes[2446] = temp_nodes[2445] && temp_nodes[2444];

  temp_nodes[2447] = temp_nodes[2431] || temp_nodes[2432];

  temp_nodes[2448] = temp_nodes[2415] || temp_nodes[2416];

  temp_nodes[2449] = !temp_nodes[2430];

  temp_nodes[2450] = temp_nodes[2420] || temp_nodes[2421];

  temp_nodes[2451] = !temp_nodes[2432];

  temp_nodes[2452] = temp_nodes[2433] && temp_nodes[2434];

  temp_nodes[2453] = temp_nodes[2435] && temp_nodes[2436];

  temp_nodes[2454] = temp_nodes[2400] || temp_nodes[2437];

  temp_nodes[2109] = w[14];

  temp_nodes[2125] = x[14];

  temp_nodes[2466] = temp_nodes[2108] || temp_nodes[2124];

  temp_nodes[2465] = !temp_nodes[2464];

  temp_nodes[2455] = temp_nodes[2107] && temp_nodes[2123];

  temp_nodes[2456] = temp_nodes[2441] && temp_nodes[2442];

  temp_nodes[2141] = y[14];

  temp_nodes[2157] = z[14];

  temp_nodes[2471] = temp_nodes[2140] || temp_nodes[2156];

  temp_nodes[2470] = !temp_nodes[2469];

  temp_nodes[2457] = temp_nodes[2139] && temp_nodes[2155];

  temp_nodes[2458] = temp_nodes[2446] && temp_nodes[2447];

  temp_nodes[2459] = temp_nodes[2448] && temp_nodes[2449];

  temp_nodes[2460] = temp_nodes[2450] && temp_nodes[2451];

  temp_nodes[2461] = temp_nodes[2433] || temp_nodes[2434];

  temp_nodes[2462] = !temp_nodes[2452];

  temp_nodes[2463] = temp_nodes[2453] && temp_nodes[2454];

  temp_nodes[2490] = temp_nodes[2109] && temp_nodes[2125];

  temp_nodes[2467] = temp_nodes[2466] && temp_nodes[2465];

  temp_nodes[2468] = temp_nodes[2455] || temp_nodes[2456];

  temp_nodes[2495] = temp_nodes[2141] && temp_nodes[2157];

  temp_nodes[2472] = temp_nodes[2471] && temp_nodes[2470];

  temp_nodes[2473] = temp_nodes[2457] || temp_nodes[2458];

  temp_nodes[2474] = temp_nodes[2441] || temp_nodes[2442];

  temp_nodes[2475] = !temp_nodes[2456];

  temp_nodes[2476] = temp_nodes[2446] || temp_nodes[2447];

  temp_nodes[2477] = !temp_nodes[2458];

  temp_nodes[2478] = temp_nodes[2459] && temp_nodes[2460];

  temp_nodes[2479] = temp_nodes[2461] && temp_nodes[2462];

  temp_nodes[2480] = temp_nodes[2426] || temp_nodes[2463];

  temp_nodes[2110] = w[15];

  temp_nodes[2126] = x[15];

  temp_nodes[2492] = temp_nodes[2109] || temp_nodes[2125];

  temp_nodes[2491] = !temp_nodes[2490];

  temp_nodes[2481] = temp_nodes[2108] && temp_nodes[2124];

  temp_nodes[2482] = temp_nodes[2467] && temp_nodes[2468];

  temp_nodes[2142] = y[15];

  temp_nodes[2158] = z[15];

  temp_nodes[2497] = temp_nodes[2141] || temp_nodes[2157];

  temp_nodes[2496] = !temp_nodes[2495];

  temp_nodes[2483] = temp_nodes[2140] && temp_nodes[2156];

  temp_nodes[2484] = temp_nodes[2472] && temp_nodes[2473];

  temp_nodes[2485] = temp_nodes[2474] && temp_nodes[2475];

  temp_nodes[2486] = temp_nodes[2476] && temp_nodes[2477];

  temp_nodes[2487] = temp_nodes[2459] || temp_nodes[2460];

  temp_nodes[2488] = !temp_nodes[2478];

  temp_nodes[2489] = temp_nodes[2479] && temp_nodes[2480];

  temp_nodes[2516] = temp_nodes[2110] && temp_nodes[2126];

  temp_nodes[2493] = temp_nodes[2492] && temp_nodes[2491];

  temp_nodes[2494] = temp_nodes[2481] || temp_nodes[2482];

  temp_nodes[2521] = temp_nodes[2142] && temp_nodes[2158];

  temp_nodes[2498] = temp_nodes[2497] && temp_nodes[2496];

  temp_nodes[2499] = temp_nodes[2483] || temp_nodes[2484];

  temp_nodes[2500] = temp_nodes[2467] || temp_nodes[2468];

  temp_nodes[2501] = !temp_nodes[2482];

  temp_nodes[2502] = temp_nodes[2472] || temp_nodes[2473];

  temp_nodes[2503] = !temp_nodes[2484];

  temp_nodes[2504] = temp_nodes[2485] && temp_nodes[2486];

  temp_nodes[2505] = temp_nodes[2487] && temp_nodes[2488];

  temp_nodes[2506] = temp_nodes[2452] || temp_nodes[2489];

  temp_nodes[2518] = temp_nodes[2110] || temp_nodes[2126];

  temp_nodes[2517] = !temp_nodes[2516];

  temp_nodes[2507] = temp_nodes[2109] && temp_nodes[2125];

  temp_nodes[2508] = temp_nodes[2493] && temp_nodes[2494];

  temp_nodes[2523] = temp_nodes[2142] || temp_nodes[2158];

  temp_nodes[2522] = !temp_nodes[2521];

  temp_nodes[2509] = temp_nodes[2141] && temp_nodes[2157];

  temp_nodes[2510] = temp_nodes[2498] && temp_nodes[2499];

  temp_nodes[2511] = temp_nodes[2500] && temp_nodes[2501];

  temp_nodes[2512] = temp_nodes[2502] && temp_nodes[2503];

  temp_nodes[2513] = temp_nodes[2485] || temp_nodes[2486];

  temp_nodes[2514] = !temp_nodes[2504];

  temp_nodes[2515] = temp_nodes[2505] && temp_nodes[2506];

  temp_nodes[2519] = temp_nodes[2518] && temp_nodes[2517];

  temp_nodes[2520] = temp_nodes[2507] || temp_nodes[2508];

  temp_nodes[2524] = temp_nodes[2523] && temp_nodes[2522];

  temp_nodes[2525] = temp_nodes[2509] || temp_nodes[2510];

  temp_nodes[2526] = temp_nodes[2493] || temp_nodes[2494];

  temp_nodes[2527] = !temp_nodes[2508];

  temp_nodes[2528] = temp_nodes[2498] || temp_nodes[2499];

  temp_nodes[2529] = !temp_nodes[2510];

  temp_nodes[2530] = temp_nodes[2511] && temp_nodes[2512];

  temp_nodes[2531] = temp_nodes[2513] && temp_nodes[2514];

  temp_nodes[2532] = temp_nodes[2478] || temp_nodes[2515];

  temp_nodes[2533] = temp_nodes[2519] && temp_nodes[2520];

  temp_nodes[2534] = temp_nodes[2524] && temp_nodes[2525];

  temp_nodes[2535] = temp_nodes[2526] && temp_nodes[2527];

  temp_nodes[2536] = temp_nodes[2528] && temp_nodes[2529];

  temp_nodes[2537] = temp_nodes[2511] || temp_nodes[2512];

  temp_nodes[2538] = !temp_nodes[2530];

  temp_nodes[2539] = temp_nodes[2531] && temp_nodes[2532];

  temp_nodes[2547] = temp_nodes[2110] && temp_nodes[2126];

  temp_nodes[2548] = temp_nodes[2142] && temp_nodes[2158];

  temp_nodes[2540] = temp_nodes[2519] || temp_nodes[2520];

  temp_nodes[2541] = !temp_nodes[2533];

  temp_nodes[2542] = temp_nodes[2524] || temp_nodes[2525];

  temp_nodes[2543] = !temp_nodes[2534];

  temp_nodes[2544] = temp_nodes[2535] && temp_nodes[2536];

  temp_nodes[2545] = temp_nodes[2537] && temp_nodes[2538];

  temp_nodes[2546] = temp_nodes[2504] || temp_nodes[2539];

  temp_nodes[2554] = temp_nodes[2519] || temp_nodes[2547];

  temp_nodes[2556] = temp_nodes[2524] || temp_nodes[2548];

  temp_nodes[2549] = temp_nodes[2540] && temp_nodes[2541];

  temp_nodes[2550] = temp_nodes[2542] && temp_nodes[2543];

  temp_nodes[2551] = temp_nodes[2535] || temp_nodes[2536];

  temp_nodes[2552] = !temp_nodes[2544];

  temp_nodes[2553] = temp_nodes[2545] && temp_nodes[2546];

  temp_nodes[2555] = temp_nodes[2554] || temp_nodes[2533];

  temp_nodes[2557] = temp_nodes[2556] || temp_nodes[2534];

  temp_nodes[2558] = temp_nodes[2549] && temp_nodes[2550];

  temp_nodes[2559] = temp_nodes[2551] && temp_nodes[2552];

  temp_nodes[2560] = temp_nodes[2530] || temp_nodes[2553];

  temp_nodes[2561] = temp_nodes[2555] && temp_nodes[2541];

  temp_nodes[2562] = temp_nodes[2557] && temp_nodes[2543];

  temp_nodes[2563] = temp_nodes[2549] || temp_nodes[2550];

  temp_nodes[2564] = !temp_nodes[2558];

  temp_nodes[2565] = temp_nodes[2559] && temp_nodes[2560];

  temp_nodes[2566] = temp_nodes[2561] && temp_nodes[2562];

  temp_nodes[2567] = temp_nodes[2563] && temp_nodes[2564];

  temp_nodes[2568] = temp_nodes[2544] || temp_nodes[2565];

  temp_nodes[2569] = temp_nodes[2561] || temp_nodes[2562];

  temp_nodes[2570] = !temp_nodes[2566];

  temp_nodes[2571] = temp_nodes[2567] && temp_nodes[2568];

  temp_nodes[2572] = temp_nodes[2569] && temp_nodes[2570];

  temp_nodes[2573] = temp_nodes[2558] || temp_nodes[2571];

  temp_nodes[2575] = temp_nodes[2572] || temp_nodes[2566];

  temp_nodes[2574] = temp_nodes[2572] && temp_nodes[2573];

  temp_nodes[2576] = temp_nodes[2575] || temp_nodes[2574];

  temp_nodes[2577] = !temp_nodes[2574];

  temp_nodes[2578] = temp_nodes[2572] || temp_nodes[2573];

  temp_nodes[2579] = temp_nodes[2567] || temp_nodes[2568];

  temp_nodes[2580] = !temp_nodes[2571];

  temp_nodes[2581] = temp_nodes[2559] || temp_nodes[2560];

  temp_nodes[2582] = !temp_nodes[2565];

  temp_nodes[2583] = temp_nodes[2545] || temp_nodes[2546];

  temp_nodes[2584] = !temp_nodes[2553];

  temp_nodes[2585] = temp_nodes[2531] || temp_nodes[2532];

  temp_nodes[2586] = !temp_nodes[2539];

  temp_nodes[2587] = temp_nodes[2505] || temp_nodes[2506];

  temp_nodes[2588] = !temp_nodes[2515];

  temp_nodes[2589] = temp_nodes[2479] || temp_nodes[2480];

  temp_nodes[2590] = !temp_nodes[2489];

  temp_nodes[2591] = temp_nodes[2453] || temp_nodes[2454];

  temp_nodes[2592] = !temp_nodes[2463];

  temp_nodes[2593] = temp_nodes[2427] || temp_nodes[2428];

  temp_nodes[2594] = !temp_nodes[2437];

  temp_nodes[2595] = temp_nodes[2401] || temp_nodes[2402];

  temp_nodes[2596] = !temp_nodes[2411];

  temp_nodes[2597] = temp_nodes[2375] || temp_nodes[2376];

  temp_nodes[2598] = !temp_nodes[2385];

  temp_nodes[2599] = temp_nodes[2349] || temp_nodes[2350];

  temp_nodes[2600] = !temp_nodes[2359];

  temp_nodes[2601] = temp_nodes[2323] || temp_nodes[2324];

  temp_nodes[2602] = !temp_nodes[2333];

  temp_nodes[2603] = temp_nodes[2297] || temp_nodes[2298];

  temp_nodes[2604] = !temp_nodes[2307];

  temp_nodes[2605] = temp_nodes[2271] || temp_nodes[2272];

  temp_nodes[2606] = !temp_nodes[2281];

  temp_nodes[2607] = temp_nodes[2576] && temp_nodes[2577];

  temp_nodes[2608] = temp_nodes[2578] && temp_nodes[2577];

  temp_nodes[2609] = temp_nodes[2579] && temp_nodes[2580];

  temp_nodes[2610] = temp_nodes[2581] && temp_nodes[2582];

  temp_nodes[2611] = temp_nodes[2583] && temp_nodes[2584];

  temp_nodes[2612] = temp_nodes[2585] && temp_nodes[2586];

  temp_nodes[2613] = temp_nodes[2587] && temp_nodes[2588];

  temp_nodes[2614] = temp_nodes[2589] && temp_nodes[2590];

  temp_nodes[2615] = temp_nodes[2591] && temp_nodes[2592];

  temp_nodes[2616] = temp_nodes[2593] && temp_nodes[2594];

  temp_nodes[2617] = temp_nodes[2595] && temp_nodes[2596];

  temp_nodes[2618] = temp_nodes[2597] && temp_nodes[2598];

  temp_nodes[2619] = temp_nodes[2599] && temp_nodes[2600];

  temp_nodes[2620] = temp_nodes[2601] && temp_nodes[2602];

  temp_nodes[2621] = temp_nodes[2603] && temp_nodes[2604];

  temp_nodes[2622] = temp_nodes[2605] && temp_nodes[2606];

  temp_nodes[2088] = true;

  temp_nodes[2089] = false;

  result[15] = temp_nodes[2607];
  result[14] = temp_nodes[2608];
  result[13] = temp_nodes[2609];
  result[12] = temp_nodes[2610];
  result[11] = temp_nodes[2611];
  result[10] = temp_nodes[2612];
  result[9] = temp_nodes[2613];
  result[8] = temp_nodes[2614];
  result[7] = temp_nodes[2615];
  result[6] = temp_nodes[2616];
  result[5] = temp_nodes[2617];
  result[4] = temp_nodes[2618];
  result[3] = temp_nodes[2619];
  result[2] = temp_nodes[2620];
  result[1] = temp_nodes[2621];
  result[0] = temp_nodes[2622];

  return absl::OkStatus();
}
